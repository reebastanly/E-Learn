<?php
	// the shopping cart needs sessions, to start one
	/*
		Array of session(
			cart => array (
				book_isbn (get from $_GET['book_isbn']) => number of books
			),
			items => 0,
			total_price => '0.00'
		)
	*/
	session_start();
	require_once "./functions/database_functions.php";
	// print out header here
	
	$title = "Checking out";
	
	if(strlen($_SESSION['login'])==0)
	{
	    header('location:index.php');
	}


?>	
	
	
	
<!DOCTYPE html>
<html lang="en">
<head>
<title>Elearn | <?php echo $title;?> </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Inspire Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->



<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup-box.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" 	href="css/chocolat.css" type="text/css" media="all">
<!--// css -->
<!-- font -->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.js"></script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
	<!-- Popup-Box-JavaScript -->
	<script src="js/modernizr.custom.97074.js"></script>
	<script src="js/jquery.chocolat.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.gallery-grids a').Chocolat();
		});
	</script>
	<!-- //Popup-Box-JavaScript -->
	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
          <!--  <script type="text/javascript" src="validate.js"></script> -->
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>
</script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.js"></script>
<style>

.userform{width: 400px;}
.userform p {
    width: 100%;
}
.userform label {
    width: 120px;
    color: #333;
    float: left;
}
input.error {
    border: 1px dotted red;
}
label.error{
    width: 100%;
    color: red;
    font-style: italic;
    margin-left: 120px;
    margin-bottom: 5px;
}
.userform input.submit {
    margin-left: 120px;
}
</style>

<script>

$(document).ready(function() {
    $("#checkout").validate({
        rules: {
          
           firstname: {
                required: true,
                minlength: 3
                        },
			lastname: {
                required: true,
                minlength: 3
                        },
			address: "required"	,
			country: "required",
			loc_state: "required",
			loc_district: "required",
			loc_city: {
                required: true,
                minlength: 3
                        },
			 zipcode: {
                required: true,
                number: true,
                maxlength: 6
                    },
			 mobileno: {
                required: true,
                number: true,
                maxlength: 10
                    },	
		    emailid: {
                required: true,
                email: true
            }
			
		
			
			
            },
        messages: {
         
            
             firstname: {
                required: "Please enter your first name",
                minlength: "Your first name must consist of at least 3 characters"
                        },
			lastname: {
                required: "Please enter your first name",
                minlength: "Your first name must consist of at least 3 characters"
                        },
			address: "please enter the address",
			country: "Please select country",
			loc_state: "Please select state",
			loc_district: "Please select district",
			loc_city: {
			     required: "please enter city",
				 minlength:"minimum 3 charactors"
				 },
			 zipcode: {
                required: "Please enter zip code",
                number: "Please enter only numeric value",
				maxlength:"maximum 6 numbers"
                    },
			mobileno: {
                required: "Please enter your phone number",
                number: "Please enter only numeric value",
				maxlength:"maximum 10 numbers"
                    },
		 emailid: "Please enter a valid email address"
			
			
           
			
        }
    });
});

</script>
	



</head>
<body>
	<div class="header">
		<div class="container">

			<div class="w3l_header_left"> 
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+ (123) 111 222 333</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>bookstore@elearn.com</li>
				</ul>
			</div>
			
			
			<div class="w3l_header_right">
				<ul>
				<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="dashboard.php">Dashboard</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="forgot_password.php">Change Password</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="user_profile.php">Profile</a></li>
					
					
					<?php if($_SESSION['login'])
                            {
                    ?> 
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="logout.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Logout</a></li>
            		<?php }?>
				</ul>
			</div>
			
		<div class="clearfix"> </div>
			
		</div>
	</div>
	<div class="logo-navigation-w3layouts">
		<div class="container">
		<div class="logo-w3">
			<a href="#"><h1><img src="images/logo.png" alt=" " /><span><strong>E-Learn</strong></span></h1></a>
		</div>
		<div class="navigation agileits w3layouts">
			<nav class="navbar agileits w3layouts navbar-default">
				<div class="navbar-header agileits w3layouts">
					<button type="button" class="navbar-toggle agileits w3layouts collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
						<span class="sr-only agileits w3layouts">Toggle navigation</span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
					</button>
				</div>

<!-- 
user icons
 -->				

        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
              <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span>&nbsp; My Cart</a></li>
                <li><a href="feedback.php"><span ></span>&nbsp; Feedback</a></li>
                <li><a href="advanced_search.php"><span ></span>&nbsp; Advanced search</a></li>
                <li><a href="user_view_orders.php"><span ></span>&nbsp; Your Orders</a></li>
                <li><a href="user_view_feedbacks.php"><span ></span>&nbsp; Your Feedbacks</a></li>
            </ul>
        </div>
        

			</nav>
		</div>
	</div>

<br>


<br>	
	


	
	
	
	
	
<?php	

if(isset($_SESSION['cart']) && (array_count_values($_SESSION['cart'])))
{
?>

<style>

.my-custom-scrollbar-menu {
  position: relative;
  left:70px;
  height: 100%;
  width:80%;

}


.table-wrapper-scroll-y {
  display: block;
}

</style>


<br><br>


<div class="table-wrapper-scroll-y my-custom-scrollbar-menu">

    <table class="table table-bordered table-striped mb-0">
    
    
        <tr>
                <td>
   	<form method="post" action="purchase.php">
	   	<table class="table">
	   		<tr>
	   			<th>Item</th>
	   			<th>Price</th>
	  			<th>Quantity</th>
	  			<th>Discount%</th>
	   			<th>Total</th>
	   		</tr>
	   		<?php
		    	foreach($_SESSION['cart'] as $bkid => $qty){
					$book_result = getBookById($bkid);
					$authorid=$book_result->Author;
					
					$sql="SELECT * from tblauthors where id=:authorid";
					
					$query=$dbh->prepare($sql);
					
					$query-> bindParam(':authorid',$authorid, PDO::PARAM_STR);
					
					$query->execute();
					
					$results=$query->fetchAll(PDO::FETCH_OBJ);
					
					if($query->rowCount() > 0)
					
					{
					    foreach($results as $result)
					    {
					        $authorname=$result->AuthorName;
					    }
					}
					
					$price=$book_result->Price;
			?>
			<tr>
				<td><?php echo $book_result->BookName . " by " . $authorname; ?></td>
				<td><?php echo "Rs." .$price;  ?></td>
				<td><input type="text" value="<?php echo $qty; ?>" size="2" name="<?php echo $bkid; ?>"></td>
				<?php 
				$discount=$book_result->DiscountPercentage;
				if ($discount > 0)
				{
				    $discount_amount= ($price * $discount)/100;
				    $price = $price - $discount_amount;
				}
				
				?>
				<td><?php echo $discount."%";?></td>
				<td><?php echo "Rs." . $qty * $price ?></td>
			</tr>
			<?php } ?>
		    <tr>
		    	<th>&nbsp;</th>
		    	<th>&nbsp;</th>
		    	<th><?php echo $_SESSION['total_items']; ?></th>
		    	<th>&nbsp;</th>
		    	<th><?php echo "Rs." . $_SESSION['total_price']; ?> /-</th>
		    </tr>
	   	</table>
	
	

	
	
<div class="container">
<div class="col-md-15 wthree_about_grid_right">
           

	<div class="wmuSliderWrapper">
								
		<div class="content-wrapper1">
			
			<div class="col-md-6 col-sm-8 col-xs-12 col-md-offset-3" >
	
	<div class="panel panel-danger">
    
    <div class="panel-heading">
    Please enter your details 
    </div>
    
    <div class="panel-body">
 	<form method="post" action="purchase.php" name="checkout" id="checkout">
 	
		<?php if(isset($_SESSION['err']) && $_SESSION['err'] == 1){ ?>
			<p class="text-danger">All fields have to be filled</p>
			<?php } ?>


<?php 

$UserId=$_SESSION['UserId'];
$sql="SELECT UserId,RegDate,FirstName,LastName,Address,Country,State,District,City,ZipCode,EmailId,MobileNumber,Password,user_photo,Status,UpdationDate from  tblUsers  where UserId=:UserId ";
$query = $dbh -> prepare($sql);
$query-> bindParam(':UserId', $UserId, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{            ?>  
            
								<div class="form-group">
                                    <label>Fisrt Name</label>
                                    <input class="form-control" type="text" name="firstname" id="firstname" autocomplete="off" value="<?php echo htmlentities($result->FirstName); ?>" required  pattern="^[a-zA-Z]+$" maxlength="15"/>
                                </div>

                                <div class="form-group">
                                <label>Last Name</label>
                                <input class="form-control" type="text" name="lastname" id="lastname" autocomplete="off" value="<?php echo htmlentities($result->LastName); ?>" required  pattern="^[a-zA-Z]+$" maxlength="15"/>
                                </div>

                                <div class="form-group">
                                <label>Address</label>
                                <input class="form-control" type="text" name="address" id="address" autocomplete="off" value="<?php echo htmlentities($result->Address); ?>" required />
                                </div>
                                
                                <div class="form-group">
                                <label>Country</label>
                                <select class="form-control" name="country" id="country" required>
                                <option value="0">Select Country</option>
									<?php
									echo $result->Country;
									$sql="SELECT * FROM country where id=$result->Country";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$c_results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($c_results as $c_result)
									    {            
                            				?>
                                            <option value="<?php echo $c_result->id; ?>" <?php if ($c_result->id == $result->Country) {echo "selected";}?>><?php echo $c_result->CountryName;?></option>
                            				<?php
                                         }
									}
                            		?>
                                </select>
                                </div>
                                
                                <div class="form-group">
                                <label>State</label>
                                <select class="form-control" name="loc_state" id="loc_state" onChange="district()" required>
                                <option value="0">Select State</option>
									<?php
									
									$sql="SELECT * FROM state";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($results as $state_result)
									    {            
                            				?>
                                            <option value="<?php echo $state_result->StCode; ?>" <?php if ($state_result->StCode == $result->State) {echo "selected";}?>><?php echo $state_result->StateName;?></option>
                            				<?php
                                         }
									}
                            		?>
                                </select>
                                </div>
                                 

                                
                                <div class="form-group">
                                <label>District</label>
                                <select class="form-control" name="loc_district" id="loc_district" required>
                                
                                <?php

									$sql="SELECT * FROM district where StCode =$result->State";
								
									$query = $dbh -> prepare($sql);
									$query->execute();
									$results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($results as $dist_result)
									    {            
                            				?>
                                            <option value="<?php echo $dist_result->DistCode; ?>"  <?php if ($dist_result->DistCode == $result->District) {echo "selected";}?> > <?php echo $dist_result->DistrictName;?></option>
                            				<?php
                                         }
									}
                            		?>
                                
                                
                                </select>
                                </div>
                                
                                     <div class="form-group">
                                <label>Enter City</label>
                                <input class="form-control" type="text" name="loc_city" id="loc_city"  value="<?php echo htmlentities($result->City); ?>"  autocomplete="off" required  />                                </div>

                                 <div class="form-group">
                                <label>Zip Code:</label>
                                <input class="form-control" type="text" name="zipcode" id="zipcode" maxlength="6" autocomplete="off" value="<?php echo htmlentities($result->ZipCode); ?>" required />

                                <div class="form-group">
                                <label>Mobile Number :</label>
                                <input class="form-control" type="text" name="mobileno"  id="mobileno" maxlength="10" autocomplete="off" value="<?php echo htmlentities($result->MobileNumber); ?>" required pattern="^\d{10}$"/>
                                </div>
                                                                        
                                <div class="form-group">
                                <label> Email</label>
                                <input class="form-control" type="email" name="emailid" id="emailid" onBlur="checkAvailability()"  value="<?php echo htmlentities($result->EmailId); ?>"  autocomplete="off" required  />
                                   <span id="user-availability-status" style="font-size:12px;"></span> 
                                </div>

<?php } }?>		
		
        
    	<div class="form-group">
    		<input type="submit" name="submit" value="Purchase" class="btn btn-danger">
   		</div>
    		
            <p>&nbsp;</p>
        </form>
     </div>
     
</div>

</div>
	<p class="lead"><h5>Please press Purchase to confirm your purchase, or Continue Shopping to add or remove items.</h5><br>
		<a href="dashboard.php" class="btn btn-danger">Continue Shopping</a></p>
</div>
</div>
</div>
</div>
	
	

<?php
	} 
	else 
	{
		echo "<p class=\"text-warning\">Your cart is empty! Please make sure you add some books in it!</p>";
	}
	

?>

                </td>
                
        </tr>
    </table>
    
</div>