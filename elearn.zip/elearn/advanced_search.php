<?php
session_start();
include('includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{

    $UserId=$_SESSION['UserId'];
    $sql="SELECT FirstName,LastName FROM tblUsers WHERE UserId ='$UserId'";
    $query=$dbh->prepare($sql);
    $query->execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    if($query->rowCount() > 0)
    {
        foreach($results as $result)
        {  
            $UserName="$result->FirstName $result->LastName";
        }
    }
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Elearn | Advanced Search</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Inspire Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->



<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup-box.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" 	href="css/chocolat.css" type="text/css" media="all">
<!--// css -->
<!-- font -->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
	<!-- Popup-Box-JavaScript -->
	<script src="js/modernizr.custom.97074.js"></script>
	<script src="js/jquery.chocolat.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.gallery-grids a').Chocolat();
		});
	</script>
	<!-- //Popup-Box-JavaScript -->
	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
          <!--  <script type="text/javascript" src="validate.js"></script> -->
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>	



</head>
<body>
	<div class="header">
		<div class="container">

			<div class="w3l_header_left"> 
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+ (123) 111 222 333</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>bookstore@elearn.com</li>
				</ul>
			</div>
			
			
			<div class="w3l_header_right">
				<ul>
				<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="dashboard.php">Dashboard</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="forgot_password.php">Change Password</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="user_profile.php">Profile</a></li>
					
					
					<?php if($_SESSION['login'])
                            {
                    ?> 
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="logout.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Logout</a></li>
            		<?php }?>
				</ul>
			</div>
			
		<div class="clearfix"> </div>
			
		</div>
	</div>
	<div class="logo-navigation-w3layouts">
		<div class="container">
		<div class="logo-w3">
			<a href="#"><h1><img src="images/logo.png" alt=" " /><span><strong>E-Learn</strong></span></h1></a>
		</div>
		<div class="navigation agileits w3layouts">
			<nav class="navbar agileits w3layouts navbar-default">
				<div class="navbar-header agileits w3layouts">
					<button type="button" class="navbar-toggle agileits w3layouts collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
						<span class="sr-only agileits w3layouts">Toggle navigation</span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
					</button>
				</div>

<!-- 
user icons
 -->				

        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
              <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span>&nbsp; My Cart</a></li>
                <li><a href="feedback.php"><span ></span>&nbsp; Feedback</a></li>
                <li><a href="advanced_search.php"><span ></span>&nbsp; Advanced search</a></li>
                <li><a href="user_view_orders.php"><span ></span>&nbsp; Your Orders</a></li>
                <li><a href="user_view_feedbacks.php"><span ></span>&nbsp; Your Feedbacks</a></li>
            </ul>
        </div>

			</nav>
		</div>
	</div>

<br>

<script>
function getsubcategory()
{
var category_id=document.getElementById('category').value;
//alert(category_id);
$.ajax({
	method: "POST",
	url: "getSubCategory.php",
	data:'category_id='+category_id,
	success: function(data){
	var r=JSON.parse(data);
	$("#subcategory").html("<option value=0>"+"Select SubCategory"+"</option>");
	
	for(i=0;i<r.length;i++)
	{
		$("#subcategory").append("<option value="+r[i].id+">"+r[i].value+"</option>");
	}
	}
	});
}

</script>


	<div class="container">
	<form runat="server" name="search_book" id="search_book" method="post" enctype="multipart/form-data">
		<table border=0 align=center>
		<tr bgcolor=#eba834>
			<td align=center colspan=5><label>Search Books</label></td>
		</tr>
		<tr bgcolor=>
			<td align=center colspan=5>&nbsp;</td>
		</tr>		
		
		<tr align=center>
		    <td><label> Category</label></td>
			<td><label>Sub Category</label></td>
			<td><label>Author</label></td>
			<td><label>Publisher</label></td>
			<td><label>Used Book</label></td>
			
			</tr>
			<tr>
    			<td align=center width=250>
    			   
    				 <select class="form-control" name="category" id="category" onChange="getsubcategory()"  required>
                                <option value="0">Select Category</option>
									<?php
									
									$sql="SELECT * FROM tblcategory where Status=1";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($results as $result)
									    {            
                            				?>
                                            <option value="<?php echo $result->id; ?>" <?php if($_POST['category']==$result->id){echo "selected";}?>><?php echo $result->CategoryName;?></option>
                            				<?php
                                         }
									}
                            		?>
                     </select>
    			</td>
    			<td  align=center width=250>
    			  
    			  
    			            <select class="form-control"  name="subcategory" id="subcategory">
                                <option value="0">Select SubCategory</option>
                                 <?php
									
									$sql="SELECT * FROM tblsubcategory where Status=1";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$subcat_results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($subcat_results as $subcat_result)
									    {            
                            				?>
                                            <option value="<?php echo $subcat_result->id; ?>" <?php if($_POST['subcategory']==$subcat_result->id){echo "selected";}?>><?php echo $subcat_result->	SubcategoryName;?></option>
                            				<?php
                                         }
									}
                            		?>
                            </select>
    			</td>
    			<td  align=center width=250>
    			
    			<select class="form-control" name="author" id="author"  required>
                                <option value="0">Select Author</option>
									<?php
									
									$sql="SELECT * FROM tblauthors where Status=1";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($results as $result)
									    {            
                            				?>
                                            <option value="<?php echo $result->id; ?>" <?php if($_POST['author']==$result->id){echo "selected";}?>><?php echo $result->AuthorName;?></option>
                            				<?php
                                         }
									}
                            		?>
                                </select>
			</td>
			<td  align=center width=250>
			
			                    <select class="form-control" name="publisher" id="publisher"  required>
                                <option value="0">Select Publisher</option>
									<?php
									
									$sql="SELECT * FROM tblpublishers where Status=1";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($results as $result)
									    {            
                            				?>
                                            <option value="<?php echo $result->id; ?>" <?php if($_POST['publisher']==$result->id){echo "selected";}?>><?php echo $result->PublisherName;?></option>
                            				<?php
                                         }
									}
                            		?>
                                </select>
			</td>
			<td  align=center width=100>
			<div class="form-group">

				<table border=0>
				  <br>
				<tr>
				<td>
				&nbsp;&nbsp;&nbsp;&nbsp;
				</td>
				<td>
                    
                 <div class="radio">
                    
                    <label>
                    <input type="radio" name="usedbook" id="usedbook" value="0" checked="checked">No
                    
                    
                    </label>
                
                </div>
                </td>
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </td>
                <td>
                    <div class="radio">
                    
                    <label>
                    <input type="radio" name="usedbook" id="usedbook" value="1">Yes
                    
                    
                    </label>
                    
                </div>
                
                </td>
                </tr>
                
                </table>
                
            </div>
			</td>
			</tr>
			<tr align=center>
                <td colspan=5>
                <br>
                <button type="submit" name="Search_Book" class="btn btn-danger" id="Search_Book">Search Book</button>
               
                </td>
            </tr>
                <td colspan=5>&nbsp;

                </td>
            </tr>
			<tr align=center  bgcolor=#eba834>
                <td colspan=5>&nbsp;

                </td>
            </tr>
		</table>
		</form>
	
	</div>

<br>

<style>

.my-custom-scrollbar-menu {
  position: relative;
  left:55px;
  height: 420px;
  width:200px;
  overflow: auto;
}

.my-custom-scrollbar-content {
  position: relative;
  left:55px;
  height: 420px;
  width:1115px;
  overflow: auto;
}


.table-wrapper-scroll-y {
  display: block;
}

</style>




<div class="table-wrapper-scroll-y my-custom-scrollbar-content">

    <table class="table table-bordered table-striped mb-0">
    
    
    <tr>
            <td align=center>
				
<table border=0>
<tr>
<?php 
$ii=0;
$sql="select * from tblbook";
if(isset($_POST['Search_Book']))
{
    
    $category=$_POST['category'];
    $subcategory=$_POST['subcategory'];
    $author=$_POST['author'];
    $publisher=$_POST['publisher'];
    $usedbook=($_POST['usedbook']);
    $tmp=0;
    
    $sql="select * from tblbook where ";
    
    if ($category!=0)
    {
        $sql=$sql."Category=$category ";
        $tmp=1;
    }
    
    if($subcategory!=0)
    {
		if($tmp==1)
		{
        $sql=$sql."and Subcategory=$subcategory ";
        }
		else
		{
		$sql=$sql."Subcategory=$subcategory ";
		}
		$tmp=1;
    }

    if($author!=0)
    {
		if($tmp==1)
		{		
        $sql=$sql."and Author=$author ";
		}
		else
		{
		$sql=$sql."Author=$author ";
		}
        $tmp=1;
    }
    
    if($publisher!=0)
    {
		if($tmp==1)
		{			
        $sql=$sql."and Publisher=$publisher ";
		}
		else
		{
		$sql=$sql."Publisher=$publisher ";
		}
        $tmp=1;
    }
    
    if($tmp==1)
    {
    $sql=$sql."and UsedBook=$usedbook";
    }
    else 
    {
        $sql=$sql."UsedBook=$usedbook";
    }
   // echo "$sql";    

}



$sql="$sql";
$query=$dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
  foreach($results as $result)
  {
    $BookName="$result->BookName";
    $BookId="$result->BookId";
    $ii++;
    
    
    ?>
<td>&nbsp;&nbsp;&nbsp;</td>
<td>

				<a href="book.php?bookid=<?php echo htmlentities($BookId);?>">
           
                                
                                <table width=200 height="200">
                                
                                	<tr>
                                		<td align=center width=100 height=150><img width="100%" height="100%" style="display:block;" id="book_image" name="book_image" src="book_image.php?bookid=<?php echo htmlentities($BookId);?>"></td>
                                	</tr>
                                	<tr>
                                	<td align=center><?php echo $BookName;?></td>
                                	</tr>
                                
                                </table>

				</a>
                
</td>



<?php

			if ($ii>4)
			{
			$ii=0;
			?>
            <tr><td colspan="3">&nbsp;&nbsp;</td></tr><tr>
            <?php
			}
 
    }
}
?>

</tr>
</table>
</div>




</body>
</html>
<?php } ?>




