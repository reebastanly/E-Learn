<?php

// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','elearn');
// Establish database connection.
try
{
    $dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
    exit("Error: " . $e->getMessage());
}


function total_price($cart)
{
    $price = 0.0;
    
    if(is_array($cart))
    {
        foreach($cart as $bkid => $qty)
        {
            $bookprice = floatval(getbookprice($bkid));
            $discount= floatval(getbookdiscount($bkid));
            if($bookprice)
            {
                if($discount >0)
                {
                    $discount_amount= ($bookprice * $discount)/100;
                    $bookprice = $bookprice - $discount_amount;
                }
                $price += $bookprice * $qty;
            }
        }
    }
    
    return $price;
}

/*
 loop through array of $_SESSION['cart'][book_isbn] => number
 $_SESSION['cart'] is associative array which is [book_isbn] => number of books for each book_isbn
 calculate sum of books
 */
function total_items($cart){
    $items = 0;
    if(is_array($cart)){
        foreach($cart as $bkid => $qty){
            $items += $qty;
        }
    }
    return $items;
}



function getBookById($bkid){
    global $dbh;
    $sql = "SELECT BookName, Author, Price, DiscountPercentage FROM tblbook WHERE BookId = '$bkid'";
    $query=$dbh->prepare($sql);
    $query->execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    if($query->rowCount() > 0)
    {
        foreach($results as $result)
        {
            return $result;
        }
        
    }
    else 
    {
    echo "Can't retrieve data";
    exit;
    }
}


function getbookprice($bkid)
{
    global $dbh;
    $sql = "SELECT Price FROM tblbook WHERE BookId = '$bkid'";
    $query = $dbh->prepare($sql);
    $query->execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    if($query->rowCount() > 0)
    {
        foreach($results as $result)
        {
            return $result->Price;
        }
    }
    else
    {
        echo "Can't retrieve data " ;
        exit;
    }

}

function getbookdiscount($bkid)
{
    global $dbh;
    $sql = "SELECT DiscountPercentage FROM tblbook WHERE BookId = '$bkid'";
    $query = $dbh->prepare($sql);
    $query->execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    if($query->rowCount() > 0)
    {
        foreach($results as $result)
        {
            return $result->DiscountPercentage;
        }
    }
    else
    {
        echo "Can't retrieve data " ;
        exit;
    }
    
}


function insertIntoOrder($orderid,$UserId,$firstname,$lastname,$address,$country,$loc_state,$loc_district,$loc_city,$mobileno,$emailid,$zipcode,$total_price,$Status)
{	
    global $dbh;
$UserName=$firstname." ". $lastname;

$sql = "INSERT INTO tblorders (OrderId,UserId,shipName,shipAddress,shipState,shipDistrict,shipCity,shipMobile,shipEmail,shipZip,shipCountry,TotalPrice,Status) VALUES
		('" . $orderid . "', '" . $UserId . "', '" . $UserName . "', '" . $address . "', '" . $loc_state . "', '" . $loc_district . "', '" . $loc_city . "', '" . $mobileno . "','" . $emailid ."','" . $zipcode . "','" . $country ."','" . $total_price . "','" . $Status ."')";
		
    $query=$dbh->prepare($sql);
    $query->execute();

	$lastInsertId = $dbh->lastInsertId();
	
	    if($lastInsertId)
        {
			$_SESSION['order_msg']="1" ; 
		}
		else
		{
		echo $sql;
		    $_SESSION['order_msg']="0" ;;
    		exit;
		}

}

/*
	function select4LatestBook($conn){
		$row = array();
		$query = "SELECT book_isbn, book_image FROM books ORDER BY book_isbn DESC";
		$result = mysqli_query($conn, $query);
		if(!$result){
		    echo "Can't retrieve data " . mysqli_error($conn);
		    exit;
		}
		for($i = 0; $i < 4; $i++){
			array_push($row, mysqli_fetch_assoc($result));
		}
		return $row;
	}



	function getOrderId($conn, $customerid){
		$query = "SELECT orderid FROM orders WHERE customerid = '$customerid'";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "retrieve data failed!" . mysqli_error($conn);
			exit;
		}
		$row = mysqli_fetch_assoc($result);
		return $row['orderid'];
	}

	function insertIntoOrder($conn, $customerid, $total_price, $date, $ship_name, $ship_address, $ship_city, $ship_zip_code, $ship_country){
		$query = "INSERT INTO orders VALUES 
		('', '" . $customerid . "', '" . $total_price . "', '" . $date . "', '" . $ship_name . "', '" . $ship_address . "', '" . $ship_city . "', '" . $ship_zip_code . "', '" . $ship_country . "')";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Insert orders failed " . mysqli_error($conn);
			exit;
		}
	}



	function getCustomerId($name, $address, $city, $zip_code, $country){
		$conn = db_connect();
		$query = "SELECT customerid from customers WHERE 
		name = '$name' AND 
		address= '$address' AND 
		city = '$city' AND 
		zip_code = '$zip_code' AND 
		country = '$country'";
		$result = mysqli_query($conn, $query);
		// if there is customer in db, take it out
		if($result){
			$row = mysqli_fetch_assoc($result);
			return $row['customerid'];
		} else {
			return null;
		}
	}

	function setCustomerId($name, $address, $city, $zip_code, $country){
		$conn = db_connect();
		$query = "INSERT INTO customers VALUES 
			('', '" . $name . "', '" . $address . "', '" . $city . "', '" . $zip_code . "', '" . $country . "')";

		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "insert false !" . mysqli_error($conn);
			exit;
		}
		$customerid = mysqli_insert_id($conn);
		return $customerid;
	}

	function getPubName($conn, $pubid){
		$query = "SELECT publisher_name FROM publisher WHERE publisherid = '$pubid'";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		if(mysqli_num_rows($result) == 0){
			echo "Empty books ! Something wrong! check again";
			exit;
		}

		$row = mysqli_fetch_assoc($result);
		return $row['publisher_name'];
	}

	function getAll($conn){
		$query = "SELECT * from books ORDER BY book_isbn DESC";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		return $result;
	}
	
	*/
?>