
<?php

session_start();

error_reporting(0);

include('includes/config.php');
if(strlen($_SESSION['adminlogin'])=='')
{ 
header('location:index.php');
}


    ?>

<html lang="en">
<head>
<title>Elearn | Manage Orders</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Inspire Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->



<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup-box.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" 	href="css/chocolat.css" type="text/css" media="all">
<!--// css -->
<!-- font -->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
	<!-- Popup-Box-JavaScript -->
	<script src="js/modernizr.custom.97074.js"></script>
	<script src="js/jquery.chocolat.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.gallery-grids a').Chocolat();
		});
	</script>
	<!-- //Popup-Box-JavaScript -->
	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
          <!--  <script type="text/javascript" src="validate.js"></script> -->
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>	

<link href="datatable/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="datatable/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" media="all" />
<script src="datatable/dataTables.bootstrap4.min.js"></script>
<script src="datatable/jquery-3.3.1.js"></script>
<script src="datatable/jquery.dataTables.min.js"></script>

</head>
<body>
	<div class="header">
		<div class="container">

			<div class="w3l_header_left"> 
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+ (123) 111 222 333</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>bookstore@elearn.com</li>
				</ul>
			</div>
			
			
			<div class="w3l_header_right">
				<ul>
				<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="admin_home.php">Admin Home</a></li>
					
				
					
					
					<?php if($_SESSION['adminlogin'])
                            {
                    ?> 
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="logout.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Logout</a></li>
            		<?php }?>
				</ul>
			</div>
	</div>
	<div class="logo-navigation-w3layouts">
		<div class="container">
		<div class="logo-w3">
			<a href="#"><h1><img src="images/logo.png" alt=" " /><span><strong>E-Learn</strong></span></h1></a>
		</div>
		<div class="navigation agileits w3layouts">
			<nav class="navbar agileits w3layouts navbar-default">
				<div class="navbar-header agileits w3layouts">
					<button type="button" class="navbar-toggle agileits w3layouts collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
						<span class="sr-only agileits w3layouts">Toggle navigation</span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
					</button>
				</div>
				<div class="navbar-collapse agileits w3layouts collapse hover-effect" id="navbar">
					<ul class="agileits w3layouts">
						
					</ul>
				</div>
			</nav>
		</div>
	</div>


	<!-- about -->
	<div class="about-w3-agile" id="about">
	<div class="contact-w3-agileits" id="contact">
		<div class="container">
				<h3>Manage Orders</h3>
			</dev>
		</div>
	</div>
				<div id="myModal" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Modal Header</h4>
						  </div>
						  <div class="modal-body">
							<p></p>
						  </div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							
							
						  </div>
						</div>
					</div>
				</div>


<!-- Form starts-->

<center>

<div style="overflow-x:auto;overflow-y:auto;width:1250;height:500;">

	
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Order Date</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>View</th>
            </tr>
        </thead>
        <tbody>
        
        
<?php
$sql="SELECT * from tblorders";
$query=$dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
    foreach($results as $result)
    {
        ?>
        
        
        
            <tr>
                <td><?php echo $result->OrderId;?></td>
                <td><?php echo $result->Order_date;?></td>
                <td><?php echo $result->shipName;?></td>
                <td><?php echo $result->shipMobile;?></td>
                <td><?php echo $result->shipEmail;?></td>
                <td><?php echo "Rs. $result->TotalPrice. /-"?></td>
                <td><?php echo $result->Status;?></td>
                <td><a href="process_order.php?oid=<?php echo $result->OrderId;?>">View<?php if($result->Status == "Ordered. Pending processing"){ echo "/Process";}?></</a></td>
            </tr>
            
            <?php }}?>
        
        </tbody>
        <tfoot>
            <tr>
                <th>Order ID</th>
                <th>Order Date</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>View</th>
            </tr>
        </tfoot>
    </table>
    
 

</div>
    
    <script>
    
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

				
		
<!-- Form END -->				
						
					</div>
					<!--<img src="images/ap.jpg" alt=" " class="img-responsive" />-->

				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
    </center>
<!-- //about -->





	<div class="featured-work">
		<div class="container">

				</div>
			</div>
			<script src="js/jquery.wmuSlider.js"></script> 
								<script>
									$('.example1').wmuSlider();         
								</script> 

			<div class="col-md-6 featured-right">
				<!--<h4>Quisque lobortis</h4>-->
				<p></p>
				<!--<p>Fusce eu felis et sapien malesuada pretium a ac eros. Praesent quis hendrerit quam. Integer mollis est a cursus pulvinar. Proin leo neque, posuere eu metus </p>
				<a href="#" data-toggle="modal" data-target="#myModal">Read More</a>-->
			</div>
			<div class="clearfix">
			</div>
		</div>
	</div>
	

