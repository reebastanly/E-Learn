<?php 
require_once("includes/config.php");

$qty=intval($_POST['qty']);
$bkid=$_POST['bkid'];

$sql ="SELECT Quantity FROM tblbook WHERE BookId=:bkid";
$query= $dbh -> prepare($sql);
$query-> bindParam(':bkid', $bkid, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
foreach ($results as $result)
{
$Quantity=intval($result->Quantity);
}

if($qty>$Quantity)
{
echo "<span style='color:red'> Only $Quantity items available in stock !!!</span>";
 echo "<script>$('#save_change').prop('disabled',true);</script>";
} 
else
{
echo "<span style='color:green'> Available.</span>";
echo "<script>$('#save_change').prop('disabled',false);</script>";
}



?>
