<?php 
session_start();
include('includes/config.php');
error_reporting(0);
if(strlen($_SESSION['bookmanager_login'])==0)
{
    header('location:index.php');
}
else
{ 

    $authorid=$_SESSION['authorid']; 
        //$UserId="UID039";
        
    $sql= "select Image from tblauthors WHERE id = $authorid";
    $query = $dbh->prepare($sql);
    $query-> execute();
    $num = $query->rowCount();

    if( $num )
    {
    $row = $query->fetch(PDO::FETCH_ASSOC);
    header("Content-type: image/jpg");
    print $row['Image'];
    }


}
?>
