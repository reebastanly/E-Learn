<?php 
require_once("includes/config.php");

if(!empty($_POST["subcatname"])) 
{
$category=$_POST["catid"];
$subcategory= $_POST["subcatname"];
$sql ="SELECT SubcategoryName FROM tblsubcategory WHERE Category=$category and SubcategoryName='$subcategory'";
$query= $dbh -> prepare($sql);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
	if($query -> rowCount() > 0)
	{
	echo "<span style='color:red'>Sub Category already existsin the selected category...</span>";
	echo "<script>$('#submit').prop('disabled',true);</script>";
	} 
	else
	{
	echo "<span style='color:green'>Sub Category name available to add in this category</span>";
	echo "<script>$('#submit').prop('disabled',false);</script>";
	}
}



?>
