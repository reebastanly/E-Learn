<?php 
require_once("includes/config.php");

if(!empty($_POST["catname"])) 
{
$category= $_POST["catname"];
$sql ="SELECT CategoryName FROM tblcategory WHERE CategoryName='$category'";
$query= $dbh -> prepare($sql);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
	if($query -> rowCount() > 0)
	{
	echo "<span style='color:red'>Category already exists ...</span>";
	echo "<script>$('#submit').prop('disabled',true);</script>";
	} 
	else
	{
	echo "<span style='color:green'>Category name available to add </span>";
	echo "<script>$('#submit').prop('disabled',false);</script>";
	}
}




?>
