<?php 
require_once("includes/config.php");

if(!empty($_POST["pubname"])) 
{
$publisher= $_POST["pubname"];
$sql ="SELECT PublisherName FROM tblpublishers WHERE PublisherName='$publisher'";
$query= $dbh -> prepare($sql);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
	if($query -> rowCount() > 0)
	{
	echo "<span style='color:red'>Publisher already exists ...</span>";
	echo "<script>$('#submit').prop('disabled',true);</script>";
	} 
	else
	{
	echo "<span style='color:green'>Publisher name available to add </span>";
	echo "<script>$('#submit').prop('disabled',false);</script>";
	}
}




?>
