<html>
<head>
<title>
</title>
<body>
<form method="POST" name="frm1">
<table border=2>
<tr>
<td>name</td>
<td><input type="text" name="name" id="name" /></td>
</tr>
<tr>
<td>id</td>
<td><input type="text" name="id" id="id" /></td>
</tr>

<tr>
<td></td>
<td><input type="File" name="pic" id="pic" /></td>

</tr>
<tr>
<td></td>
<td><input type="submit" name="ok" id="ok" value="ok"/></td>

</tr>
</table>
</form>
<?php
if(isset($_POST['ok']))
{
$db_host="localhost";
$db_name="elearn2";
$db_user="root";
$db_pass="";
try
{
$dbh=new PDO("mysql:host=$db_host;dbname=$db_name",$db_user,$db_pass,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch(PDOException $e)
{
Exit("Error".$e->getMessage());
}
$n=$_POST['name'];
$i=$_POST['id'];
//$imgData = addslashes(file_get_contents($_FILES['pic']['tmp_name']))
$sql="insert into test2 values('neema',5)";
$query=$dbh->prepare($sql);
$query->execute();
}
?>