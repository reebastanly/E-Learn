<?php 
session_start();
include('includes/config.php');
error_reporting(0);

    $BookId=$_GET['bookid'];
        
    $sql= "select image from tblbook WHERE BookId = '$BookId'";
    $query = $dbh->prepare($sql);
    $query-> execute();
    $num = $query->rowCount();

    if( $num )
    {
    $row = $query->fetch(PDO::FETCH_ASSOC);
    header("Content-type: image/jpg");
    print $row['image'];
    }
	

?>
