<?php 

session_start();
require_once "./functions/database_functions.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Elearn | My Cart</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Inspire Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->



<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup-box.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" 	href="css/chocolat.css" type="text/css" media="all">
<!--// css -->
<!-- font -->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
	<!-- Popup-Box-JavaScript -->
	<script src="js/modernizr.custom.97074.js"></script>
	<script src="js/jquery.chocolat.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.gallery-grids a').Chocolat();
		});
	</script>
	<!-- //Popup-Box-JavaScript -->
	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
          <!--  <script type="text/javascript" src="validate.js"></script> -->
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>	



</head>
<body>
	<div class="header">
		<div class="container">

			<div class="w3l_header_left"> 
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+ (123) 111 222 333</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>bookstore@elearn.com</li>
				</ul>
			</div>
			
			
			<div class="w3l_header_right">
				<ul>
				<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="dashboard.php">Dashboard</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="forgot_password.php">Change Password</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="user_profile.php">Profile</a></li>
					
					
					<?php if($_SESSION['login'])
                            {
                    ?> 
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="logout.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Logout</a></li>
            		<?php }?>
				</ul>
			</div>
			
		<div class="clearfix"> </div>
			
		</div>
	</div>
	<div class="logo-navigation-w3layouts">
		<div class="container">
		<div class="logo-w3">
			<a href="#"><h1><img src="images/logo.png" alt=" " /><span><strong>E-Learn</strong></span></h1></a>
		</div>
		<div class="navigation agileits w3layouts">
			<nav class="navbar agileits w3layouts navbar-default">
				<div class="navbar-header agileits w3layouts">
					<button type="button" class="navbar-toggle agileits w3layouts collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
						<span class="sr-only agileits w3layouts">Toggle navigation</span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
					</button>
				</div>

<!-- 
user icons
 -->				

        <div id="navbar" class="navbar-collapse collapse">
         <ul class="nav navbar-nav navbar-right">
              <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span>&nbsp; My Cart</a></li>
                <li><a href="feedback.php"><span ></span>&nbsp; Feedback</a></li>
                <li><a href="advanced_search.php"><span ></span>&nbsp; Advanced search</a></li>
                <li><a href="user_view_orders.php"><span ></span>&nbsp; Your Orders</a></li>
                <li><a href="user_view_feedbacks.php"><span ></span>&nbsp; Your Feedbacks</a></li>
            </ul>
        </div>
        

			</nav>
		</div>
	</div>

<br>


<br>

<?php

	// the shopping cart needs sessions, to start one
	/*
		Array of session(
			cart => array (
				book_isbn (get from $_POST['book_isbn']) => number of books
			),
			items => 0,
			total_price => '0.00'
		)
	*/


	//require_once "./functions/cart_functions.php";

	// book_isbn got from form post method, change this place later.
	if(isset($_POST['bookid'])){
		$book_id = $_POST['bookid'];
		
	}
	

	if(isset($book_id))
	{
		// new iem selected
		if(!isset($_SESSION['cart'])){
		     
			// $_SESSION['cart'] is associative array that bookid => qty
			$_SESSION['cart'] = array();

			$_SESSION['total_items'] = 0;
			$_SESSION['total_price'] = '0.00';
		}

		if(!isset($_SESSION['cart'][$book_id]))
		{
			$_SESSION['cart'][$book_id] = 1;
		} 
		elseif(isset($_POST['cart']))
		{
			$_SESSION['cart'][$book_id]++;

			
			unset($_POST);
		}
	}

	// if save change button is clicked , change the qty of each bookisbn
	
	if(isset($_POST['save_change']))
	{
        
	    
	    foreach($_SESSION['cart'] as $bkid =>$qty)
		{
			if($_POST[$bkid] == '0')
			{
				unset($_SESSION['cart']["$bkid"]);
			} 
			else 
			{
				$_SESSION['cart']["$bkid"] = $_POST["$bkid"];
			}
		}
	}
	
	
    

	
	/*function check($cart) 
	{
	    if(is_array($cart))
	    {
	        foreach($cart as $bkid => $qty)
	        {
	            echo $bkid."-----".$qty;
	        }
	    }
	}*/
	

	// print out header here
	$title = "Your shopping cart";

	if(isset($_SESSION['cart']) && (array_count_values($_SESSION['cart'])))
	{
	    $_SESSION['total_price'] = total_price($_SESSION['cart']);

	    $_SESSION['total_items'] = total_items($_SESSION['cart']);
		
	    //check($_SESSION['cart']);

	    
	
		
?>

<style>

.my-custom-scrollbar-menu {
  position: relative;
  left:70px;
  height: 100%;
  width:90%;

}


.table-wrapper-scroll-y {
  display: block;
}

</style>


<br><br>

<script>
function checkquantity(bkid) {
//alert(bkid);
$("#loaderIcon").show();
jQuery.ajax({
url: "check_quantity.php",
data:'qty='+$("#"+bkid+"").val()+'&bkid='+bkid,
type: "POST",
success:function(data){
$("#"+bkid+"-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>



<div class="table-wrapper-scroll-y my-custom-scrollbar-menu">

    <table class="table table-bordered table-striped mb-0">
    
    
        <tr>
                <td>
   	<form action="cart.php" method="post">
	   	<table class="table">
	   		<tr>
	   			<th>Item</th>
	   			<th>Price</th>
	  			<th>Quantity</th>
	  			<th>Discount%</th>
	   			<th>Total</th>
	   		</tr>
	   		<?php
		    	foreach($_SESSION['cart'] as $bkid => $qty){
					$book_result = getBookById($bkid);
					$authorid=$book_result->Author;
					
					$sql="SELECT * from tblauthors where id=:authorid";
					
					$query=$dbh->prepare($sql);
					
					$query-> bindParam(':authorid',$authorid, PDO::PARAM_STR);
					
					$query->execute();
					
					$results=$query->fetchAll(PDO::FETCH_OBJ);
					
					if($query->rowCount() > 0)
					
					{
					    foreach($results as $result)
					    {
					        $authorname=$result->AuthorName;
					    }
					}
					
					$price=$book_result->Price;
			?>
			<tr>
				<td><?php echo $book_result->BookName . " by " . $authorname; ?></td>
				<td><?php echo "Rs." .$price;  ?></td>
				<td><input type="text" onBlur="checkquantity('<?php echo $bkid; ?>')" value="<?php echo $qty; ?>" size="2" name="<?php echo $bkid; ?>" id="<?php echo $bkid; ?>">
                <span id="<?php echo $bkid;?>-availability-status" style="font-size:12px;"></span>
                </td>
				<?php 
				$discount=$book_result->DiscountPercentage;
				if ($discount > 0)
				{
				    $discount_amount= ($price * $discount)/100;
				    $price = $price - $discount_amount;
				}
				
				?>
				<td><?php echo $discount."%";?></td>
				<td><?php echo "Rs." . $qty * $price ?></td>
			</tr>
			<?php } ?>
		    <tr>
		    	<th>&nbsp;</th>
		    	<th>&nbsp;</th>
		    	<th><?php echo $_SESSION['total_items']; ?></th>
		    	<th>&nbsp;</th>
		    	<th><?php echo "Rs." . $_SESSION['total_price']; ?> /-</th>
		    </tr>
	   	</table>
	   	<input type="submit" class="btn btn-danger" id="save_change" name="save_change" value="Save Changes">
	</form>
	<br/><br/>
	<a href="checkout.php" class="btn btn-danger">Go To Checkout</a> 
	<a href="dashboard.php" class="btn btn-danger">Continue Shopping</a>
<?php
	} else {
		echo "<p class=\"text-warning\">Your cart is empty! Please make sure you add some books in it!</p>";
	}

?>

                </td>
                
        </tr>
    </table>
    
</div>