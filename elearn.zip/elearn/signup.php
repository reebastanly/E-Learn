

<?php 


session_start();
include('includes/config.php');

error_reporting(0);
$_SESSION['updatemsg']="";
if(isset($_POST['signup']))
{
//code for captach verification
if ($_POST["vercode"] != $_SESSION["vercode"] OR $_SESSION["vercode"]=='')  {
        echo "<script>alert('Incorrect verification code');</script>" ;
    } 
        else {    
//Code for user ID
$count_my_page = ("userid.txt");
$hits = file($count_my_page);
$hits[0] ++;
$fp = fopen($count_my_page , "w");
fputs($fp , "$hits[0]");
fclose($fp); 
$UserId= $hits[0];   
$fname=$_POST['firstname'];
$lname=$_POST['lastname'];
$Address=$_POST['address'];
$Country=$_POST['loc_country'];
$State=$_POST['loc_state'];
$District=$_POST['loc_district'];
$City=$_POST['loc_city'];
$ZipCode=$_POST['zipcode'];
$mobileno=$_POST['mobileno'];
$email=$_POST['email']; 
$password=md5($_POST['password']); 
$status=1;

    
$sql="INSERT INTO tblUsers(UserId,FirstName,LastName,Address,Country,State,District,City,ZipCode,EmailId,MobileNumber,Password,Status) VALUES(:UserId,:fname,:lname,:address,:country,:state,:district,:city,:zipcode,:email,:mobileno,:password,:status)";
$query = $dbh->prepare($sql);

$query->bindParam(':UserId',$UserId,PDO::PARAM_STR);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':lname',$lname,PDO::PARAM_STR);
$query->bindParam(':address',$Address,PDO::PARAM_STR);
$query->bindParam(':country',$Country,PDO::PARAM_STR);
$query->bindParam(':state',$State,PDO::PARAM_STR);
$query->bindParam(':district',$District,PDO::PARAM_STR);
$query->bindParam(':city',$City,PDO::PARAM_STR);
$query->bindParam(':zipcode',$ZipCode,PDO::PARAM_INT);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':mobileno',$mobileno,PDO::PARAM_STR);
$query->bindParam(':password',$password,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);


$query->execute();

$lastInsertId = $dbh->lastInsertId();


        if($lastInsertId)
        {   
                if(!isset($_FILES['user_photo']))
                {
                    echo '<p>Please Select a profile picture</p>';
                    
                }
                else
                {
                    try
                    {
                        $msg = upload($UserId); // function calling to upload an image
                    }
                    catch(Exception $e)
                    {
                        echo $e->getMessage();
                        echo 'Sorry, Could not upload file';
                    }
                }
                
                if($msg=="1")
                {
                    $_SESSION['updatemsg']="<font color='green'>Your Profile has been created successfully. Your ID is $UserId</font>";
                }
                else 
                {
                    $_SESSION['updatemsg']="<font color='red'>Profile created - UserID:$UserId but image could not be uploaded. Please set it from your profile.</font>";
                }
                
                //header('location:signin.php');
        
        }
        else 
        {
            $_SESSION['updatemsg']="<font color='red'>Something Went wrong. Please try again.</font>";
        }

}
}


function upload($UserId)
{
    include('includes/config.php');
    $maxsize = 10000000; //set to approx 10 MB
    
    //check associated error code
    if($_FILES['user_photo']['error']==UPLOAD_ERR_OK)
    {
        
        //check whether file is uploaded with HTTP POST
        if(is_uploaded_file($_FILES['user_photo']['tmp_name']))
        {
            
            //checks size of uploaded image on server side
            if( $_FILES['user_photo']['size'] < $maxsize)
            {
                //checks whether uploaded file is of image type
                if($_FILES['user_photo']['type']=="image/gif" || $_FILES['user_photo']['type']== "image/png" || $_FILES['user_photo']['type']== "image/jpeg" || $_FILES['user_photo']['type']== "image/JPEG" || $_FILES['user_photo']['type']== "image/PNG" || $_FILES['user_photo']['type']== "image/GIF")
                {
				
                    // prepare the image for insertion
                    $imgData = addslashes(file_get_contents($_FILES['user_photo']['tmp_name']));                 
                    $sql = "update tblUsers set user_photo='{$imgData}' where UserId='$UserId'";
                    $query = $dbh->prepare($sql);
                    $query->execute();
                    
                    $lastInsertId=$query->rowCount();
                    
                    
                    if($lastInsertId==1)
                    {
                        $msg="<font color='green'>Image successfully saved in database</font>";
                        $msg="1";
                    }
                    else
                    {
                        $msg="<font color='red'>Some error occured</font>";
                        $msg="2";
                    }

                    
                }
                else
				{
				
                    $msg="<p>Uploaded file is not an image.</p>";
				}
            }
            else
            {
                // if the file is not less than the maximum allowed, print an error
                $msg='<div>File exceeds the Maximum File limit</div>
                <div>Maximum File limit is '.$maxsize.' bytes</div>
                <div>File '.$_FILES['user_photo']['name'].' is '.$_FILES['user_photo']['size'].
                ' bytes</div><hr />';
            }
        }
        else
            $msg="File not uploaded successfully.";
            
    }
    else
    {
        $msg= file_upload_error_message($_FILES['user_photo']['error']);
    }
    return $msg;
}

// Function to return error message based on error code

function file_upload_error_message($error_code)

{
    switch ($error_code) {
        case UPLOAD_ERR_INI_SIZE:
            return 'The uploaded file exceeds the upload_max_filesize directive in php.ini';
        case UPLOAD_ERR_FORM_SIZE:
            return 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
        case UPLOAD_ERR_PARTIAL:
            return 'The uploaded file was only partially uploaded';
        case UPLOAD_ERR_NO_FILE:
            return 'No file was uploaded';
        case UPLOAD_ERR_NO_TMP_DIR:
            return 'Missing a temporary folder';
        case UPLOAD_ERR_CANT_WRITE:
            return 'Failed to write file to disk';
        case UPLOAD_ERR_EXTENSION:
            return 'File upload stopped by extension';
        default:
            return 'Unknown upload error';
    }
}


?>




<html lang="en">
<head>
<title>Elearn | Sign up</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Inspire Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->



<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup-box.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" 	href="css/chocolat.css" type="text/css" media="all">
<!--// css -->
<!-- font -->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<!--<script src="js/jquery-1.11.1.min.js"></script>-->

<script src="js/jquery-1.11.1.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.js"></script>
<script src="js/bootstrap.js"></script>
	<!-- Popup-Box-JavaScript -->
	<script src="js/modernizr.custom.97074.js"></script>
	<script src="js/jquery.chocolat.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.gallery-grids a').Chocolat();
		});
	</script>
	<!-- //Popup-Box-JavaScript -->
	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
          <!--  <script type="text/javascript" src="validate.js"></script> -->
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>	



<script type="text/javascript">
function valid()
{
if(document.signup.password.value!= document.signup.confirmpassword.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.signup.confirmpassword.focus();
return false;	
}
return true;
}
</script>
<script>
function checkAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'emailid='+$("#emailid").val(),
type: "POST",
success:function(data){
$("#user-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>    

<script>
function district()
{
var st=document.getElementById('loc_state').value;

$.ajax({
	method: "POST",
	url: "getCity.php",
	data:'state_id='+st,
	success: function(data){
	var r=JSON.parse(data);
	$("#loc_district").html("<option value=0>"+"Select District"+"</option>");
	
	for(i=0;i<r.length;i++)
	{
		$("#loc_district").append("<option value="+r[i].id+">"+r[i].value+"</option>");
	}
	}
	});
}




</script>
<style>

.userform{width: 400px;}
.userform p {
    width: 100%;
}
.userform label {
    width: 120px;
    color: #333;
    float: left;
}
input.error {
    border: 1px dotted red;
}
label.error{
    width: 100%;
    color: red;
    font-style: italic;
    margin-left: 120px;
    margin-bottom: 5px;
}
.userform input.submit {
    margin-left: 120px;
}
</style>

<script>

$(document).ready(function() {
    $("#signup").validate({
        rules: {
            user_photo: "required",
            firstname: {
                required: true,
                minlength: 3
                        },
			lastname: {
                required: true,
                minlength: 3
                        },
			address: "required"	,
			 zipcode: {
                required: true,
                number: true,
                minlength: 6
            },
			loc_state: "required",
			 mobileno: {
                required: true,
                number: true,
                maxlength: 10
                    },	
		    emailid: {
                required: true,
                email: true
            },
			
			 password: {
                required: true,
                minlength: 6
            },
             confirmpassword: {
                required: true,
                minlength: 6,
                equalTo: "#password"
            }
			
			
            },
        messages: {
            user_photo: "Please select image",
            
            firstname: {
                required: "Please enter your first name",
                minlength: "Your first name must consist of at least 3 characters"
                        },
			 lastname: {
                required: "Please enter your first name",
                minlength: "Your first name must consist of at least 3 characters"
                        },
			address: "please enter the address",
			zipcode: {
                required: "Please enter zipcode number",
                number: "Please enter only numeric value"
            },
			loc_state: "Please select state",
			mobileno: {
                required: "Please enter your phone number",
                number: "Please enter only numeric value",
				maxlength:"maximum 10 numbers"
                    },
			emailid: "Please enter a valid email address",
			
			 password: {
                required: "Please provide a password",
                minlength: "Your password must be at least 6 characters long"
            },
            confirmpassword: {
                required: "Please provide a password",
                minlength: "Your password must be at least 6 characters long",
                equalTo: "Please enter the same password as above"
            }
			
        }
    });
});

</script>


</head>
<body>
	<div class="header">
		<div class="container">
			<div class="w3l_header_left"> 
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+ (123) 111 222 333</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>bookstore@elearn.com<a href="mailto:info@example.com">
					
				</a></li>
				</ul>
			</div>
			
			<div class="w3l_header_right">
				<ul>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="signin.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Sign In</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="signup.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Sign Up</a></li>
				</ul>
			</div>
			
			<div class="clearfix"> </div>
			
		</div>
	</div>
	<div class="logo-navigation-w3layouts">
		<div class="container">
		<div class="logo-w3">
			<a href="#"><h1><img src="images/logo.png" alt=" " /><span><strong>E-Learn</strong></span></h1></a>
		</div>
		<div class="navigation agileits w3layouts">
			<nav class="navbar agileits w3layouts navbar-default">
				<div class="navbar-header agileits w3layouts">
					<button type="button" class="navbar-toggle agileits w3layouts collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
						<span class="sr-only agileits w3layouts">Toggle navigation</span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
					</button>
				</div>
				<div class="navbar-collapse agileits w3layouts collapse hover-effect" id="navbar">
					<ul class="agileits w3layouts">
						<li class="agileits w3layouts"><a href="index.php" >Home</a></li>
						<li class="agileits w3layouts"><a href="index.php#about">About</a></li>
						<li class="agileits w3layouts"><a href="index.php#services">Services</a></li>
						<li class="agileits w3layouts"><a href="index.php#gallery">Gallery</a></li>
						<li class="agileits w3layouts"><a class="scroll" href="#contact">Contact</a></li>
					</ul>
				</div>
			</nav>
		</div>
	</div>


	<!-- about -->
	<div class="about-w3-agile" id="about">
		<div class="container">
			<div class="wthree_about_grids">
				<div class="col-md-2 wthree_about_grid_left">
					<h3>SIGN UP</h3>
					<h2><p> something here </p></h2>
								<!--<a href="#" data-toggle="modal" data-target="#myModal">Read More</a>-->
				</div>
				<div id="myModal" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Modal Header</h4>
						  </div>
						  <div class="modal-body">
							<p></p>
						  </div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						  </div>
						</div>
					</div>
				</div>

				<div class="col-md-15 wthree_about_grid_right">
           

	<div class="wmuSliderWrapper">
								
		<div class="content-wrapper1">
			
			<div class="col-md-6 col-md-offset-3">
			
			<label><?php echo $_SESSION["updatemsg"];?></label> <br><br>
       
			
             	<div class="panel panel-danger">
                        <div class="panel-heading">
                           Sign up..
                        </div>
                        
                        <div class="panel-body">
                            <form runat="server" name="signup" id="signup" method="post" enctype="multipart/form-data" onSubmit="return valid();">

								<div class="form-group">
                                    <label>Upload your photo</label>	
                                    <table>
                                    	<tr>	
                                    		<td>
                                    		<input class="form-control" type="file" name="user_photo" id="user_photo" autocomplete="off"  />
                                    		</td>
                                    		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                    		<td>
                                    			<table width=100 height=100 border=1>
                                    			<tr><td width=100 height=100 align=center><img width="100%" height="100%" style="display:block;" id="user_image" name="user_image" src="images/1.png"></td></tr>
                                    			</table>
                                    		</td>
                                    	</tr>
                                    </table>
                                    
                                             
                                </div>                           
                           		                            
								<div class="form-group">
                                    <label>Enter Fisrt Name</label>
                                    <input class="form-control"  type="text" name="firstname" id="firstname" autocomplete="off"    />
                                </div>

                                <div class="form-group">
                                <label>Enter Last Name</label>
                                <input class="form-control" type="text" name="lastname" id="lastname" autocomplete="off" required  pattern="^[a-zA-Z]+$" maxlength="15"/>
                                </div>

                                <div class="form-group">
                                <label>Enter Address</label>
                                <input class="form-control" id="address" type="text" name="address" autocomplete="off"  />
                                </div>
                                  <div class="form-group">
                                <label>Enter Your Country</label>
                                <select class="form-control" name="loc_country" id="loc_country"  required>
                                <option value="0">Select Country</option>
									<?php
									
									$sql="SELECT * FROM country";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($results as $result)
									    {            
                            				?>
                                            <option value="<?php echo $result->id; ?>"><?php echo $result->CountryName;?></option>
                            				<?php
                                         }
									}
                            		?>
                                </select>
                                </div>
                                
                                <div class="form-group">
                                <label>Enter Your State</label>
                                <select class="form-control" name="loc_state" id="loc_state" onChange="district()" required>
                                <option value="0">Select State</option>
									<?php
									
									$sql="SELECT * FROM state";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($results as $result)
									    {            
                            				?>
                                            <option value="<?php echo $result->StCode; ?>"><?php echo $result->StateName;?></option>
                            				<?php
                                         }
									}
                            		?>
                                </select>
                                </div>
                                 
                                
                                <div class="form-group">
                                <label>Enter Your District</label>
                                <select class="form-control" name="loc_district" id="loc_district" required>
                                </select>
                                </div>
                                <div class="form-group">
                                <label>Enter City</label>
                                <input class="form-control" type="text" name="loc_city" id="loc_city" autocomplete="off" required  />
                                </div>
                                <div class="form-group">
                                <label>ZipCode</label>
                                <input class="form-control" type="text" name="zipcode" id="zipcode" autocomplete="off" required  />
                                </div>

                                <div class="form-group">
                                <label>Mobile Number :</label>
                                <input class="form-control" type="text" name="mobileno" id="mobileno" maxlength="10" autocomplete="off" required pattern="^\d{10}$" />
                                </div>
                                                                        
                                <div class="form-group">
                                <label>Enter Email</label>
                                <input class="form-control" type="email" name="email" id="emailid" onBlur="checkAvailability()"  autocomplete="off" required  />
                                   <span id="user-availability-status" style="font-size:12px;"></span> 
                                </div>
                                
                                <div class="form-group">
                                <label>Enter Password</label>
                                <input class="form-control" type="password" name="password" id="password" autocomplete="off" required  />
                                </div>
                                
                                <div class="form-group">
                                <label>Confirm Password </label>
                                <input class="form-control"  type="password" name="confirmpassword" id="confirmpassword" autocomplete="off" required  />
                                </div>
                                 <div class="form-group">
                                <label>Verification code : </label>
                                <input type="text"  name="vercode" id="vercode" maxlength="5" autocomplete="off" required style="width: 150px; height: 25px;" />&nbsp;<img src="captcha.php" style="width: 100px; height: 26px;">
                                </div>   
                                
                                                             
								<button type="submit" name="signup" class="btn btn-danger" id="submit">Register Now </button>

                             </form>
                         </div>
                     </div>
               </div>
         </div>
     </div>
 </div>
						
						
						
					</div>
					<!--<img src="images/ap.jpg" alt=" " class="img-responsive" />-->

				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //about -->





	<div class="featured-work">
		<div class="container">

				</div>
			</div>
			<script src="js/jquery.wmuSlider.js"></script> 
								<script>
									$('.example1').wmuSlider();         
								</script> 

			<div class="col-md-6 featured-right">
				<!--<h4>Quisque lobortis</h4>-->
				<p></p>
				<!--<p>Fusce eu felis et sapien malesuada pretium a ac eros. Praesent quis hendrerit quam. Integer mollis est a cursus pulvinar. Proin leo neque, posuere eu metus </p>
				<a href="#" data-toggle="modal" data-target="#myModal">Read More</a>-->
			</div>
			<div class="clearfix">
			</div>
		</div>
	</div>

	
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        
        reader.onload = function (e) {
            $('#user_image').attr('src', e.target.result);
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

$("#user_photo").change(function(){
    readURL(this);
});
                                    
</script>         
	

