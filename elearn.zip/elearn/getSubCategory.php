
<?php 

include('includes/config.php');

$subcategory=array();
$ii=0;

$category_id=$_POST["category_id"];

$sql="SELECT id,SubcategoryName FROM tblsubcategory WHERE Status=1 and Category=$category_id";
$query=$dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0)
{
    foreach($results as $result)
    {   
        $did= $result->id;
        $dname= $result->SubcategoryName;
        $subcategory[$ii]['id']=$did;
        $subcategory[$ii]['value']=$dname;
        $ii++;
    }
}
echo json_encode($subcategory);

?>