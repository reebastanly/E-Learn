<?php 
session_start();
include('includes/config.php');
error_reporting(0);

if ($_SESSION['UserId_Edit']!="")
{
	$UserId=$_SESSION['UserId_Edit'];
	$_SESSION['UserId_Edit']="";
}
else
{
    $UserId=$_SESSION['UserId']; 
}       
        
    $sql= "select user_photo from tblUsers WHERE UserId = '$UserId'";
    $query = $dbh->prepare($sql);
    $query-> execute();
    $num = $query->rowCount();

    if( $num )
    {
    $row = $query->fetch(PDO::FETCH_ASSOC);
    header("Content-type: image/jpg");
    print $row['user_photo'];
    }



?>
