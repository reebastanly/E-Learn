
<?php

session_start();

error_reporting(0);



include('includes/config.php');



if(isset($_POST['update']))

{
$bookid=intval($_GET['bookid']);
$book=$_POST['book'];
$category=$_POST['category'];
$subcategory=$_POST['subcategory'];
$author=$_POST['author'];
$publisher=$_POST['publisher'];
$edition=$_POST['edition'];
$isbn=$_POST['isbn'];
$price=$_POST['price'];
$pages=$_POST['pages'];
$quantity=$_POST['quantity'];
$status=$_POST['status'];


$sql="update tblbook set BookName=:book,Category=:category,Subcategory=:subcategory,Author=:author,Publisher=:publisher,Edition=:edition,ISBN=:isbn,Price=:price,Pages=:pages,Quantity=:quantity,Status=:status where id=:bookid";

$query = $dbh->prepare($sql);

$query->bindParam(':book',$book,PDO::PARAM_STR);
$query->bindParam(':category',$category,PDO::PARAM_STR);
$query->bindParam(':subcategory',$subcategory,PDO::PARAM_STR);
$query->bindParam(':author',$author,PDO::PARAM_STR);
$query->bindParam(':publisher',$publisher,PDO::PARAM_STR);
$query->bindParam(':edition',$edition,PDO::PARAM_INT);
$query->bindParam(':isbn',$isbn,PDO::PARAM_INT);
$query->bindParam(':price',$price,PDO::PARAM_INT);
$query->bindParam(':pages',$pages,PDO::PARAM_STR);
$query->bindParam(':quantity',$quantity,PDO::PARAM_STR);
$query->bindParam(':bookid',$bookid,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);


$query->execute();

                if(isset($_FILES['image']))
                {
                    try
                    {
                        $msg = upload($bookid); // function calling to upload an image
                    }
                    catch(Exception $e)
                    {
                        echo $e->getMessage();
                        echo 'Sorry, Could not upload file';
                    }
                }
                
                if($msg=="1")
                {
                    $_SESSION['updatemsg']="Book details  has been updated successfully.";
                }
                else
                {
                    $_SESSION['updatemsg']="Book details updated but image could not be uploaded. Please try again";
                }


}









function upload($bookid)
{
    include('includes/config.php');
    $maxsize = 10000000; //set to approx 10 MB
    
    //check associated error code
    if($_FILES['image']['error']==UPLOAD_ERR_OK)
    {
        
        //check whether file is uploaded with HTTP POST
        if(is_uploaded_file($_FILES['image']['tmp_name']))
        {
            
            //checks size of uploaded image on server side
            if( $_FILES['image']['size'] < $maxsize)
            {
                //checks whether uploaded file is of image type
                if($_FILES['image']['type']=="image/gif" || $_FILES['image']['type']== "image/png" || $_FILES['image']['type']== "image/jpeg" || $_FILES['image']['type']== "image/JPEG" || $_FILES['image']['type']== "image/PNG" || $_FILES['image']['type']== "image/GIF")
                {
                    // prepare the image for insertion
                    $imgData = addslashes(file_get_contents($_FILES['image']['tmp_name']));
                    $sql = "update tblbook set image='{$imgData}' where id='$bookid'";
                    $query = $dbh->prepare($sql);
                    $query->execute();
                    
                    $lastInsertId=$query->rowCount();
                    
                    
                    if($lastInsertId==1)
                    {
                        $msg="<font color='green'>Image successfully saved in database</font>";
                        $msg="1";
                    }
                    else
                    {
                        $msg="<font color='red'>Some error occured</font>";
                        $msg="2";
                    }
                    
                    
                }
                else
                    $msg="<p>Uploaded file is not an image.</p>";
            }
            else
            {
                // if the file is not less than the maximum allowed, print an error
                $msg='<div>File exceeds the Maximum File limit</div>
                <div>Maximum File limit is '.$maxsize.' bytes</div>
                <div>File '.$_FILES['image']['name'].' is '.$_FILES['image']['size'].
                ' bytes</div><hr />';
            }
        }
        else
            $msg="File not uploaded successfully.";
            
    }
    else
    {
        $msg= file_upload_error_message($_FILES['image']['error']);
    }
    return $msg;
}

// Function to return error message based on error code

function file_upload_error_message($error_code)

{
    switch ($error_code) {
        case UPLOAD_ERR_INI_SIZE:
            return 'The uploaded file exceeds the upload_max_filesize directive in php.ini';
        case UPLOAD_ERR_FORM_SIZE:
            return 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
        case UPLOAD_ERR_PARTIAL:
            return 'The uploaded file was only partially uploaded';
        case UPLOAD_ERR_NO_FILE:
            return 'No file was uploaded';
        case UPLOAD_ERR_NO_TMP_DIR:
            return 'Missing a temporary folder';
        case UPLOAD_ERR_CANT_WRITE:
            return 'Failed to write file to disk';
        case UPLOAD_ERR_EXTENSION:
            return 'File upload stopped by extension';
        default:
            return 'Unknown upload error';
    }
}

?>


<html lang="en">
<head>
<title>Elearn | Edit Book</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Inspire Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->



<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />   
<link href="css/popup-box.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" 	href="css/chocolat.css" type="text/css" media="all">
<!--// css -->
<!-- font -->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->


<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
	<!-- Popup-Box-JavaScript -->
	<script src="js/modernizr.custom.97074.js"></script>
	<script src="js/jquery.chocolat.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.gallery-grids a').Chocolat();
		});
	</script>
	<!-- //Popup-Box-JavaScript -->
	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
          <!--  <script type="text/javascript" src="validate.js"></script> -->
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>	
<script src="js/jquery-1.11.1.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.js"></script>


<style>

.userform{width: 400px;}
.userform p {
    width: 100%;
}
.userform label {
    width: 120px;
    color: #333;
    float: left;
}
input.error {
    border: 1px dotted red;
}
label.error{
    width: 100%;
    color: red;
    font-style: italic;
    margin-left: 120px;
    margin-bottom: 5px;
}
.userform input.submit {
    margin-left: 120px;
}
</style>
<script>
$(document).ready(function() {
    $("#edit_book").validate({
    rules: {
           
           book: {
                required: true,
                 minlength:5
                 },
         // image: "required",
          edition: {
                required: true,
				number:true
               
                   } ,
           isbn: {
                required: true
				
                 },
           pages: {
                required: true,
				number:true
			      },
           quantity: {
                required: true,
				number: true
                     },
           price: {
                required: true,
				number: true
                  }, 
            status: "required"	
             },
            messages: {
            book: {  
		         required: "Please enter book name",
                 minlength: "Book name must be at least 5 characters long"
                   },
            //image: "Please select image",
            edition: {  
		         required: "Please enter book edition",
                 number: "Please enter only numeric value"
                
                 },
            isbn:  {  
		         required: "Please enter ISBN",
                 number: "Please enter only numeric value"
				},
            pages: {  
		         required: "Please enter number of pages",
                 number: "Please enter only numeric value"
			       },
            quantity: {  
		         required: "Please enter quantity",
				 number: "Please enter only numeric value"
                 },
             price: {  
		         required: "Please enter price",
				 number: "Please enter only numeric value"
                 },
             status: "please select status"
                   }
    });
});

</script>
                
                 
                
                 
             	         
    


<script>
function getsubcategory()
{
var category_id=document.getElementById('category').value;
//alert(category_id);
$.ajax({
	method: "POST",
	url: "getSubCategory.php",
	data:'category_id='+category_id,
	success: function(data){
	var r=JSON.parse(data);
	$("#subcategory").html("<option value=0>"+"Select SubCategory"+"</option>");
	
	for(i=0;i<r.length;i++)
	{
		$("#subcategory").append("<option value="+r[i].id+">"+r[i].value+"</option>");
	}
	}
	});
}

</script>

</head>
<body>
	<div class="header">
		<div class="container">

			<div class="w3l_header_left"> 
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+ (123) 111 222 333</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>bookstore@elearn.com</li>
				</ul>
			</div>
			
			
			<div class="w3l_header_right">
				<ul>
				<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="index.php">Home</a></li>
				<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="bookmanager_home.php">Bookmanager</a></li>
						
					
					<?php if($_SESSION['bookmanager_login'])
                            {
                    ?> 
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="logout.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Logout</a></li>
            		<?php }?>
				</ul>
				</div>
			</nav>
		</div>
	</div>


		<!-- about -->
	<div class="about-w3-agile" id="about">
		<div class="container">
			<div class="wthree_about_grids">
				<div class="col-md-2 wthree_about_grid_left">
					<h3>Edit Book</h3>
					
					<!--<table border=1>
					<tr>
					<td><img src="images/img11.jpg" height=250 width=350></td>
					</tr>
					</table>-->
					

				</div>
				<div id="myModal" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Modal Header</h4>
						  </div>
						  <div class="modal-body">
							<p></p>
						  </div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							
							
						  </div>
						</div>
					</div>
				</div>



<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3"">

<div class="panel panel-danger">

<div class="panel-heading">Book Details</div>

 

<div class="panel-body">

<form runat="server" name="edit_book" id="edit_book"  method="post" enctype="multipart/form-data" onSubmit="return valid();">

<?php 

$bookid=intval($_GET['bookid']);

$sql="SELECT * from tblbook where id=:bookid";

$query=$dbh->prepare($sql);

$query-> bindParam(':bookid',$bookid, PDO::PARAM_INT);

$query->execute();

$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0)

{

foreach($results as $result)

{               
	$BkId=$result->BookId;
  ?> 

<div class="form-group">

<label>Book Name</label>

<input class="form-control" type="text" name="book" id="book" value="<?php echo htmlentities($result->BookName);?>" required />

</div>



			<div class="form-group">
                                    <label>Upload a new photo</label>	
                                    <table>
                                    	<tr>	
                                    		<td>
                                    		<input class="form-control" type="file" name="image" id="image" autocomplete="off" />
                                    		</td>
                                    		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                    		<td>
                                    			<table width=100 height=100 border=1>
                                    			<tr><td width=100 height=100 align=center><img width="100%" height="100%" style="display:block;" id="book_image" name="book_image" src="book_image.php?bookid=<?php echo htmlentities($BkId);?>"></td></tr>
                                    			</table>
                                    		</td>
                                    	</tr>
                                    </table>
                                    
                                             
                                </div> 



								<div class="form-group">
                                <label>Category</label>
                                <select class="form-control" name="category" id="category" onChange="getsubcategory()"  required>
                                <option value="0">Select Category</option>
									<?php
									$catid=$result->Category;
									$sql="SELECT * FROM tblcategory where Status=1";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$cat_results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($cat_results as $cat_result)
									    {            
                            				?>
                                            <option value="<?php echo $cat_result->id; ?>"  <?php if ($cat_result->id == $catid) {echo "selected";}?>  ><?php echo $cat_result->CategoryName;?></option>
                            				<?php
                                         }
									}
                            		?>
                                </select>
                                </div>



                                <div class="form-group">
                                <label>Subcategory</label>
                                <select class="form-control" name="subcategory" id="subcategory"  required>
                                <option value="0">Select SubCategory</option>
                                 <?php
									$subcatid=$result->Subcategory;
									$sql="SELECT * FROM tblsubcategory where Status=1";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$subcat_results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($subcat_results as $subcat_result)
									    {            
                            				?>
                                            <option value="<?php echo $subcat_result->id; ?>"  <?php if ($subcat_result->id == $subcatid) {echo "selected";}?>  ><?php echo $subcat_result->SubcategoryName;?></option>
                            				<?php
                                         }
									}
                            		?>
                                </select>
                                </div>
      <div class="form-group">
      <label>Author</label>
      <select class="form-control" name="author" id="author"  required>
     <option value="0">Select Author</option>

									<?php


									$authid=$result->Author;
									$sql="SELECT * FROM tblauthors where Status=1";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$auth_results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($auth_results as $auth_result)
									    {            
                            				?>
                                            <option value="<?php echo $auth_result->id; ?>" <?php if ($auth_result->id == $authid) {echo "selected";}?>  ><?php echo $auth_result->AuthorName;?></option> 
                                            <?php
                                         }
									}
                            		?>
                                </select>
                                </div>
                              
  <div class="form-group">
      <label>Publisher</label>
      <select class="form-control" name="publisher" id="publisher"  required>
     <option value="0">Select Publisher</option>

<?php
									$pubid=$result->Publisher;
									$sql="SELECT * FROM tblpublishers where Status=1";
									$query = $dbh -> prepare($sql);
									$query->execute();
									$pub_results=$query->fetchAll(PDO::FETCH_OBJ);
									$cnt=1;
									
									if($query->rowCount() > 0)
									{
									    foreach($pub_results as $pub_result)
									    {            
                            				?>
                                            <option value="<?php echo $pub_result->id; ?>" <?php if ($pub_result->id == $pubid) {echo "selected";}?>  ><?php echo $pub_result->PublisherName;?></option> 
                            				<?php
                                         }
									}
                            		?>
                                </select>
                                </div>
                                
                                
<div class="form-group">

<label>Edition</label>

<input class="form-control" type="text" name="edition" id="edition" value="<?php echo htmlentities($result->Edition);?>" required />

</div>

<div class="form-group">

<label>ISBN</label>

<input class="form-control" type="text" name="isbn" id="isbn" value="<?php echo htmlentities($result->ISBN);?>" required />

</div>

<div class="form-group">

<label>pages</label>

<input class="form-control" type="text" name="pages" id="pages" value="<?php echo htmlentities($result->Pages);?>" required />

</div>
<div class="form-group">

<label>Quantity</label>

<input class="form-control" type="text" name="quantity" id="quantity" value="<?php echo htmlentities($result->Quantity);?>" required />

</div>
<div class="form-group">

<label>price</label>

<input class="form-control" type="text" name="price" id="price" value="<?php echo htmlentities($result->Price);?>" required />

</div>
<div class="form-group">


<div class="form-group">

<label>Status</label>

<?php if($result->Status==1) {?>

 <div class="radio">

<label>

<input type="radio" name="status" id="status" value="1" checked="checked">Active

</label>

</div>

<div class="radio">

<label>

<input type="radio" name="status" id="status" value="0">Inactive

</label>

</div>

<?php } else { ?>

<div class="radio">

<label>

<input type="radio" name="status" id="status" value="0" checked="checked">Inactive

</label>

</div>

 <div class="radio">

<label>

<input type="radio" name="status" id="status" value="1">Active

</label>

</div>

<?php } ?>

</div>

<?php }} ?>

<button type="submit" name="update" class="btn btn-info">Update </button>



                                    </form>

                            </div>

                        </div>

                            </div>



        </div>

   

    </div>

    </div>

     <!-- CONTENT-WRAPPER SECTION END-->

	<div class="featured-work">
		<div class="container">

				</div>
			</div>
			<script src="js/jquery.wmuSlider.js"></script> 
								<script>
									$('.example1').wmuSlider();         
								</script> 

			<div class="col-md-6 featured-right">
				<!--<h4>Quisque lobortis</h4>-->
				<p></p>
				<!--<p>Fusce eu felis et sapien malesuada pretium a ac eros. Praesent quis hendrerit quam. Integer mollis est a cursus pulvinar. Proin leo neque, posuere eu metus </p>
				<a href="#" data-toggle="modal" data-target="#myModal">Read More</a>-->
			</div>
			<div class="clearfix">
			</div>
		</div>
	</div>
	
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        
        reader.onload = function (e) {
            $('#book_image').attr('src', e.target.result);
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

$("#image").change(function(){
    readURL(this);
});
                                    
</script>  
