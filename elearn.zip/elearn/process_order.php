
<?php

session_start();

error_reporting(1);

include('includes/config.php');
if(strlen($_SESSION['adminlogin'])=='')
{ 
header('location:index.php');
}

$order_id=$_GET['oid'];


if(isset($_POST['Process']))
{
$sql="update tblorders set Status='Processed' where OrderId='$order_id'";
$query=$dbh->prepare($sql);
$query->execute();
//header('location:manage_orders.php');
    //https://techblogchain.com/configure-xampp-to-send-mail-through-localhost-2018/
    
    /* configure C:\xampp\php\php.ini and c:\xampp\sendmail\sendmail.ini for Gmail to send mail.
     * 
     * In C:\xampp\php\php.ini find extension=php_openssl.dll and remove the semicolon from the 
     * beginning of that line to make SSL working for Gmail for localhost.
     * 
     * in php.ini file find [mail function] and change
     * 
     * SMTP= smtp.gmail.com
        smtp_port=587
        sendmail_from = my-gmail-id@gmail.com
        sendmail_path = "\"C:\xampp\sendmail\sendmail.exe\" -t"
     * 
     * 
     */
    
    $to_email = 'akhilstanly@gmail.com';
    $subject = 'Testing PHP Mail';
    $message = 'This mail is sent using the PHP mail function';
    $headers = 'From:reebastanly@gmail.com';

	try{
    mail($to_email,$subject,$message,$headers);
	}
	catch(Exception $e)
	{
	echo "$e->getMessage();";
	}
    echo "Akhilllllllllll";
    
}


$sql="SELECT * from tblorders where OrderId='$order_id'";
$query=$dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
?>


<html lang="en">
<head>
<title>Elearn | Process Orders</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Inspire Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->



<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup-box.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" 	href="css/chocolat.css" type="text/css" media="all">
<!--// css -->
<!-- font -->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
	<!-- Popup-Box-JavaScript -->
	<script src="js/modernizr.custom.97074.js"></script>
	<script src="js/jquery.chocolat.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.gallery-grids a').Chocolat();
		});
	</script>
	<!-- //Popup-Box-JavaScript -->
	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
          <!--  <script type="text/javascript" src="validate.js"></script> -->
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>	



</head>
<body>
	<div class="header">
		<div class="container">

			<div class="w3l_header_left"> 
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+ (123) 111 222 333</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>bookstore@elearn.com</li>
				</ul>
			</div>
			
			
			<div class="w3l_header_right">
				<ul>
				<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="admin_home.php">Admin Home</a></li>
					
				
					
					
					<?php if($_SESSION['adminlogin'])
                            {
                    ?> 
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="logout.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Logout</a></li>
            		<?php }?>
				</ul>
			</div>
	</div>
	<div class="logo-navigation-w3layouts">
		<div class="container">
		<div class="logo-w3">
			<a href="#"><h1><img src="images/logo.png" alt=" " /><span><strong>E-Learn</strong></span></h1></a>
		</div>
		<div class="navigation agileits w3layouts">
			<nav class="navbar agileits w3layouts navbar-default">
				<div class="navbar-header agileits w3layouts">
					<button type="button" class="navbar-toggle agileits w3layouts collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
						<span class="sr-only agileits w3layouts">Toggle navigation</span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
					</button>
				</div>
				<div class="navbar-collapse agileits w3layouts collapse hover-effect" id="navbar">
					<ul class="agileits w3layouts">
						
					</ul>
				</div>
			</nav>
		</div>
	</div>


	<!-- about -->
	<div class="about-w3-agile" id="about">
	<div class="contact-w3-agileits" id="contact">
		<div class="container">
				<h3>Process Orders</h3>
			</dev>
		</div>
	</div>
				<div id="myModal" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Modal Header</h4>
						  </div>
						  <div class="modal-body">
							<p></p>
						  </div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							
							
						  </div>
						</div>
					</div>
				</div>


<!-- Form starts-->



   <style type="text/css">
	.TFtable{
		//width:500; 
		border-collapse:collapse; 
	}
	.TFtable td{ 
		padding:7px; border:#eba834 1px solid;
	}
	.TFtable th{ 
		padding:7px; border:#eba834 1px solid; background: #eba834;
	}
	/* provide some minimal visual accomodation for IE8 and below */
	.TFtable tr{
		background: #b8d1f3;
	}
	/*  Define the background color for all the ODD background rows  */
	.TFtable tr:nth-child(odd){ 
		background: #efefed;
	}
	/*  Define the background color for all the EVEN background rows  */
	.TFtable tr:nth-child(even){
		background: #fcfcfc;
	}
</style>


<form role="form" method="post">

<table class="TFtable" width=500 align=center border=1>
                <tr>
                	<th colspan=2>
                	<center><font color=white>Order Details</font></center>
                	</th>
                </tr>


<?php 

if($query->rowCount() > 0)
{
    foreach($results as $result)
    {
        ?>

                <tr>
                	<td>Order ID</td><td><?php echo $result->OrderId;?></td>
                </tr>
                <tr>
                	<td>Order Date</td><td><?php echo $result->Order_date;?></td>
                </tr>
                <tr>
                	<td>Name</td><td><?php echo $result->shipName;?></td>
                </tr>
                <tr>
         	    	<td>Address</td><td><?php echo $result->shipAddress;?></td>
         	    </tr>
         	    <tr>
                	<td>Country</td><td><?php echo $result->shipCountry;?></td>
                </tr>
                
                <?php 
                
                $sql="SELECT StateName FROM state where StCode=$result->shipState";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $st_results=$query->fetchAll(PDO::FETCH_OBJ);
                
                if($query->rowCount() > 0)
                {
                    foreach($st_results as $st_result)
                    { 
                        $state_name=$st_result->StateName;
                    }
                }
                ?>
                
                
                <tr>
                	<td>State</td><td><?php echo $state_name;?></td>
                </tr>
                
                <?php 
				$sql="SELECT * FROM district where DistCode=$result->shipDistrict";
				
				$query = $dbh -> prepare($sql);
				$query->execute();
				$dt_results=$query->fetchAll(PDO::FETCH_OBJ);

				if($query->rowCount() > 0)
				{
					foreach($dt_results as $dt_result)
					{                       
					    $district_name=$dt_result->DistrictName;
					}
				}
                ?>
                <tr>
                	<td>District</td><td><?php echo $district_name;?></td>
                </tr>
                <tr>
                	<td>City</td><td><?php echo $result->shipCity;?></td>
                </tr>
                <tr>
                	<td>Zip</td><td><?php echo $result->shipZip;?></td>
                </tr>
                <tr>
                	<td>Mobile</td><td><?php echo $result->shipMobile;?></td>
                </tr>
                <tr>
                	<td>Email</td><td><?php echo $result->shipEmail;?></td>
                </tr>
                <tr>
                	<td>Total Price</td><td><?php echo "Rs. $result->TotalPrice. /-"?></td>
                </tr>
                <tr>
                	<td>Status</td><td><?php echo $result->Status;?></td>
                </tr>
<?php }}?>

</table>




<link href="akhil/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="akhil/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" media="all" />
<script src="akhil/dataTables.bootstrap4.min.js"></script>
<script src="akhil/jquery-3.3.1.js"></script>
<script src="akhil/jquery.dataTables.min.js"></script>


<br><br>

	
<table class="TFtable" align=center border=1>
        <thead>
            <tr style="color: white;">
                <th>Serial No.</th>
                <th>Book ID</th>
                <th>Book Name</th>
                <th>Used Book</th>
         	    <th>Unit Price</th>
                <th>Quantity</th>
                <th>Discount%</th>
                <th>Total Price</th>
                
            </tr>
        </thead>
        <tbody>
        
        
<?php
$sql="SELECT * from tblorderitems where OrderId='$order_id'";
//echo $sql;
$query=$dbh->prepare($sql);
$query->execute();
$order_results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
    $cnt=0;
    $price=0;
    $quantity=0;
    
    foreach($order_results as $order_result)
    {
        $cnt++;
        
        ?>
        
        
        
            <tr>
                <td><?php echo $cnt;?></td>
                <td><?php echo $order_result->BookId;?></td>
                
                <?php 
                
                $sql="SELECT * from tblbook where BookId='$order_result->BookId'";
                //echo $sql;
                $query=$dbh->prepare($sql);
                $query->execute();
                $book_results=$query->fetchAll(PDO::FETCH_OBJ);
                //echo $query->rowCount();
                if($query->rowCount() > 0)
                {
                    
                    foreach($book_results as $book_result)
                    {
                        $book_name=$book_result->BookName;
                        $total_price=0;
                        
                        if ($book_result->UsedBook == 0)
                        {
                            $used_book="No";
                        }
                        elseif ($book_result->UsedBook == 1)
                        {
                            $used_book="Yes";
                        }
                        
                        $discount=$book_result->DiscountPercentage;
                        
                        $total_price= ($order_result->item_price * $order_result->quantity);
                        if ($discount > 0)
                        {
                            $discount_amount= ($total_price * $discount)/100;
                            $total_price = $total_price - $discount_amount;
                        }
                        
                        ?>
                        
                        
                        <td><?php echo $book_name;?></td>
                        <td><?php echo $used_book;?></td>
                        <td><?php echo $order_result->item_price;?></td>
                        <td><?php echo $order_result->quantity;?></td>
                        
                        <?php $quantity= $quantity+$order_result->quantity; ?>
                        
                        <td><?php echo $discount;?></td>
                        <td><?php echo $total_price;?></td>
                        
                        <?php $price=$price+$total_price; ?>
                                
                                
                        <?php 
                                
                                
                                
                            }
                        }
                        else 
                        {
                            ?>
                            <td colspan=6 style="color: red;">This book is currently unavailable</td>
                            <?php 

                        }
                        
                        ?>
                
                

                

            </tr>
            
            <?php }}?>
        
        </tbody>

            <tr style="color: white;">
                <th colspan=5 align="right">Total:</td>
                <th><?php echo $quantity;?></th>
                <th>&nbsp;</th>
                <th><?php echo $price; ?> </th>
            </tr>

    </table>
    
 

</div>

<br>

<?php if($result->Status == "Ordered. Pending processing"){?>
<center><input type=submit name="Process" id="Process" value="Process this order"></center>
<?php }?>
</form>


				
		
<!-- Form END -->				
						
					</div>
					<!--<img src="images/ap.jpg" alt=" " class="img-responsive" />-->

				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //about -->





	<div class="featured-work">
		<div class="container">

				</div>
			</div>
			<script src="js/jquery.wmuSlider.js"></script> 
								<script>
									$('.example1').wmuSlider();         
								</script> 

			<div class="col-md-6 featured-right">
				<!--<h4>Quisque lobortis</h4>-->
				<p></p>
				<!--<p>Fusce eu felis et sapien malesuada pretium a ac eros. Praesent quis hendrerit quam. Integer mollis est a cursus pulvinar. Proin leo neque, posuere eu metus </p>
				<a href="#" data-toggle="modal" data-target="#myModal">Read More</a>-->
			</div>
			<div class="clearfix">
			</div>
		</div>
	</div>
	

