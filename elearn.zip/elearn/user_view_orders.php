
<?php

session_start();

error_reporting(0);

include('includes/config.php');
if(strlen($_SESSION['login'])=='')
{ 
header('location:index.php');
}


    ?>

<html lang="en">
<head>
<title>Elearn | View Orders</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Inspire Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->



<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup-box.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" 	href="css/chocolat.css" type="text/css" media="all">
<!--// css -->
<!-- font -->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
	<!-- Popup-Box-JavaScript -->
	<script src="js/modernizr.custom.97074.js"></script>
	<script src="js/jquery.chocolat.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.gallery-grids a').Chocolat();
		});
	</script>
	<!-- //Popup-Box-JavaScript -->
	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
          <!--  <script type="text/javascript" src="validate.js"></script> -->
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>	

<link href="datatable/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="datatable/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" media="all" />
<script src="datatable/dataTables.bootstrap4.min.js"></script>
<script src="datatable/jquery-3.3.1.js"></script>
<script src="datatable/jquery.dataTables.min.js"></script>

</head>
<body>
	<body>
	<div class="header">
		<div class="container">
			<div class="w3l_header_left"> 
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+99999999</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>bookstore@elearn.com</li>
				</ul>
			</div>
			
			<div class="w3l_header_right">
			
			<?php 
			
			if (isset($_SESSION['login']))
			{
			?>
				<ul>
				    <li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="index.php">Home</a></li>
                    <li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="dashboard.php">Dashboard</a></li>
					
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="user_profile.php">Profile</a></li>
                    
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="logout.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Logout</a></li>
                    </ul>
            		<?php }
					else {?>
			    <ul>
			    	<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="signin.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Sign In</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="signup.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Sign Up</a></li>
				</ul>
			    
			<?php } ?>
			
			</div>
			
			<div class="clearfix"> </div>
			
		</div>
	</div>
	<div class="logo-navigation-w3layouts">
		<div class="container">
		<div class="logo-w3">
			<a href="#"><h1><img src="images/logo.png" alt=" " /><span><strong>E-Learn</strong></span></h1></a>
		</div>
		<div class="navigation agileits w3layouts">
			<nav class="navbar agileits w3layouts navbar-default">
				<div class="navbar-header agileits w3layouts">
					<button type="button" class="navbar-toggle agileits w3layouts collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
						<span class="sr-only agileits w3layouts">Toggle navigation</span>
					</button>
				</div>

			</nav>
		</div>
	</div>

<table align=right>
<tr><td>
				<a href="cart.php" style="color:#666666"><span class="glyphicon glyphicon-shopping-cart" style="color:#666666"></span>&nbsp; My Cart</a>
                <a href="feedback.php" style="color:#666666"><span ></span>&nbsp; Feedback</a>
                <a href="advanced_search.php" style="color:#666666"><span  style="color:#666666"></span>&nbsp; Advanced search</a>
                <a href="user_view_orders.php" style="color:#666666"><span  style="color:#666666"></span>&nbsp; Your Orders</a>
                <a href="user_view_feedbacks.php" style="color:#666666"><span  style="color:#666666"></span>&nbsp; Your Feedbacks</a>
</td></tr>
</table>
        
	<!-- about -->

	<div class="contact-w3-agileits" id="contact">
		<div class="container">
				<h3>Your Orders</h3>
			</dev>
		</div>
	</div>


<!-- Form starts-->

<center>

<div style="overflow-x:auto;overflow-y:auto;width:1200;height:500;">

	
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Order Date</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>View</th>
            </tr>
        </thead>
        <tbody>
        
        
<?php
$UserId=$_SESSION['UserId'];
$sql="SELECT * from tblorders where UserId='$UserId'";
$query=$dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
    foreach($results as $result)
    {
        ?>
        
        
        
            <tr>
                <td><?php echo $result->OrderId;?></td>
                <td><?php echo $result->Order_date;?></td>
                <td><?php echo $result->shipName;?></td>
                <td><?php echo $result->shipMobile;?></td>
                <td><?php echo $result->shipEmail;?></td>
                <td><?php echo "Rs. $result->TotalPrice. /-"?></td>
                <td><?php echo $result->Status;?></td>
                <td><a href="user_view_order_details.php?oid=<?php echo $result->OrderId;?>">View<?php if($result->Status == "Ordered. Pending processing"){echo "/Cancel";}?></</a></td>
            </tr>
            
            <?php }}?>
        
        </tbody>
        <tfoot>
            <tr>
                <th>Order ID</th>
                <th>Order Date</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>View</th>
            </tr>
        </tfoot>
    </table>
    
 

</div>
    
    <script>
    
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

				
		
<!-- Form END -->				
						
					</div>
					<!--<img src="images/ap.jpg" alt=" " class="img-responsive" />-->

				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
    </center>
<!-- //about -->





	<div class="featured-work">
		<div class="container">

				</div>
			</div>
			<script src="js/jquery.wmuSlider.js"></script> 
								<script>
									$('.example1').wmuSlider();         
								</script> 

			<div class="col-md-6 featured-right">
				<!--<h4>Quisque lobortis</h4>-->
				<p></p>
				<!--<p>Fusce eu felis et sapien malesuada pretium a ac eros. Praesent quis hendrerit quam. Integer mollis est a cursus pulvinar. Proin leo neque, posuere eu metus </p>
				<a href="#" data-toggle="modal" data-target="#myModal">Read More</a>-->
			</div>
			<div class="clearfix">
			</div>
		</div>
	</div>
	

