<?php 
require_once("includes/config.php");

if(!empty($_POST["authorname"])) 
{
$author= $_POST["authorname"];
$sql ="SELECT AuthorName FROM tblauthors WHERE AuthorName='$authorname'";
$query= $dbh -> prepare($sql);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
	if($query -> rowCount() > 0)
	{
	echo "<span style='color:red'>Author already exists ...</span>";
	echo "<script>$('#submit').prop('disabled',true);</script>";
	} 
	else
	{
	echo "<span style='color:green'>Author name available to add </span>";
	echo "<script>$('#submit').prop('disabled',false);</script>";
	}
}




?>
