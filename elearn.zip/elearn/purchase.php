<?php
	session_start();
	$_SESSION['err'] = 1;
	foreach($_POST as $key => $value){
		if(trim($value) == ''){
			$_SESSION['err'] = 0;
		}
		break;
	}

	if($_SESSION['err'] == 0){
		header("Location: checkout.php");
	} else {
		unset($_SESSION['err']);
	}


	$_SESSION['ship'] = array();
	foreach($_POST as $key => $value){
		if($key != "submit"){
			$_SESSION['ship'][$key] = $value;
		}
	}
	require_once "./functions/database_functions.php";
	// print out header here
	$title = "Purchase";
	
	
	?>
	
	<script src="js/jquery-1.11.1.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.min.js"></script>
<script src="jquery-validation-1.19.0/dist/jquery.validate.js"></script>

<style>

.userform{width: 400px;}
.userform p {
    width: 100%;
}
.userform label {
    width: 120px;
    color: #333;
    float: left;
}
input.error {
    border: 1px dotted red;
}
label.error{
    width: 100%;
    color: red;
    font-style: italic;
    margin-left: 120px;
    margin-bottom: 5px;
}
.userform input.submit {
    margin-left: 120px;
}
</style>

<script>

$(document).ready(function() {
    $("#process").validate({
        rules: {
          
            card_type: "required",
			card_number: {
                required: true,
				 number: true,
                minlength: 16
                        },
			
			card_PID: {
                required: true,
                number: true,
                maxlength: 4
                    },
			 card_expire: "required"
		   card_owner: {
                required: true,
                minlength:8
            }
			
		
			
			
            },
        messages: {
         
            
          card_type : "Please select your card type",
               
                     
			 card_number: {
                required: "Please enter your card number",
                minlength: "card number consist of at least 16 numbers"
                        },
			card_PID: {
			    required: "Please enter your card PIN",
                minlength: "card PIN consist of at least 4 numbers"
				}
			card_expire: "Please select expiry date",
			card_owner: {
                required: "Please enter owner name",
               
				minlength:"Name must be atleast 8 charactors"
                    }
			
			
           
			
        }
    });
});

</script>
	
	
	
	<!DOCTYPE html>
<html lang="en">
<head>
<title>Elearn | Sign in</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Inspire Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->



<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup-box.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" 	href="css/chocolat.css" type="text/css" media="all">
<!--// css -->
<!-- font -->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
	<!-- Popup-Box-JavaScript -->
	<script src="js/modernizr.custom.97074.js"></script>
	<script src="js/jquery.chocolat.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.gallery-grids a').Chocolat();
		});
	</script>
	<!-- //Popup-Box-JavaScript -->
	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
          <!--  <script type="text/javascript" src="validate.js"></script> -->
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>	



</head>
<body>
	<div class="header">
		<div class="container">

			<div class="w3l_header_left"> 
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+ (123) 111 222 333</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>bookstore@elearn.com</li>
				</ul>
			</div>
			
			
			<div class="w3l_header_right">
				<ul>
				<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="dashboard.php">Dashboard</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="forgot_password.php">Change Password</a></li>
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="user_profile.php">Profile</a></li>
					
					
					<?php if($_SESSION['login'])
                            {
                    ?> 
					<li><a class="book  button-isi zoomIn animated" data-wow-delay=".5s" href="logout.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Logout</a></li>
            		<?php }?>
				</ul>
			</div>
			
		<div class="clearfix"> </div>
			
		</div>
	</div>
	<div class="logo-navigation-w3layouts">
		<div class="container">
		<div class="logo-w3">
			<a href="#"><h1><img src="images/logo.png" alt=" " /><span><strong>E-Learn</strong></span></h1></a>
		</div>
		<div class="navigation agileits w3layouts">
			<nav class="navbar agileits w3layouts navbar-default">
				<div class="navbar-header agileits w3layouts">
					<button type="button" class="navbar-toggle agileits w3layouts collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
						<span class="sr-only agileits w3layouts">Toggle navigation</span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
						<span class="icon-bar agileits w3layouts"></span>
					</button>
				</div>

<!-- 
user icons
 -->				

        <div id="navbar" class="navbar-collapse collapse">
         <ul class="nav navbar-nav navbar-right">
              <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span>&nbsp; My Cart</a></li>
                <li><a href="feedback.php"><span ></span>&nbsp; Feedback</a></li>
                <li><a href="advanced_search.php"><span ></span>&nbsp; Advanced search</a></li>
                <li><a href="user_view_orders.php"><span ></span>&nbsp; Your Orders</a></li>
                <li><a href="user_view_feedbacks.php"><span ></span>&nbsp; Your Feedbacks</a></li>
            </ul>
        </div>
        

			</nav>
		</div>
	</div>

<br>


<br>	
	


	
	
	
	<?php

	// connect database
	if(isset($_SESSION['cart']) && (array_count_values($_SESSION['cart']))){
?>



<style>

.my-custom-scrollbar-menu {
  position: relative;
  left:70px;
  height: 100%;
  width:90%;

}


.table-wrapper-scroll-y {
  display: block;
}

</style>


<br><br>


<div class="table-wrapper-scroll-y my-custom-scrollbar-menu">

    <table class="table table-bordered table-striped mb-0">

        <tr>
                <td>
   	
        <b>Items in your Cart</b><br>
        
	<table class="table">
	   		<tr>
	   			<th>Item</th>
	   			<th>Price</th>
	  			<th>Quantity</th>
	  			<th>Discount%</th>
	   			<th>Total</th>
	   		</tr>
	   		<?php
		    	foreach($_SESSION['cart'] as $bkid => $qty){
					$book_result = getBookById($bkid);
					$authorid=$book_result->Author;
					
					$sql="SELECT * from tblauthors where id=:authorid";
					
					$query=$dbh->prepare($sql);
					
					$query-> bindParam(':authorid',$authorid, PDO::PARAM_STR);
					
					$query->execute();
					
					$results=$query->fetchAll(PDO::FETCH_OBJ);
					
					if($query->rowCount() > 0)
					
					{
					    foreach($results as $result)
					    {
					        $authorname=$result->AuthorName;
					    }
					}
					
					$price=$book_result->Price;
			?>
			<tr>
				<td><?php echo $book_result->BookName . " by " . $authorname; ?></td>
				<td><?php echo "Rs." .$price;  ?></td>
				<td><input type="text" value="<?php echo $qty; ?>" size="2" name="<?php echo $bkid; ?>"></td>
				<?php 
				$discount=$book_result->DiscountPercentage;
				if ($discount > 0)
				{
				    $discount_amount= ($price * $discount)/100;
				    $price = $price - $discount_amount;
				}
				
				?>
				<td><?php echo $discount."%";?></td>
				<td><?php echo "Rs." . $qty * $price ?></td>
			</tr>
			<?php } ?>
		    <tr>
		    	<th>&nbsp;</th>
		    	<th>&nbsp;</th>
		    	<th><?php echo $_SESSION['total_items']; ?></th>
		    	<th>&nbsp;</th>
		    	<th><?php echo "Rs." . $_SESSION['total_price']; ?> /-</th>
		    </tr>
	   	</table>
        	


<div class="container">
<div class="col-md-15 wthree_about_grid_right">
           

	<div class="wmuSliderWrapper">
								
		<div class="content-wrapper1">
			
			<div class="col-md-6 col-sm-8 col-xs-12 col-md-offset-3" >
	
	<div class="panel panel-danger">
    
    <div class="panel-heading">
    Please enter Card details for Payment
    </div>
    
    <div class="panel-body">


        	
		<form method="post" action="process.php" name="process" id="process"class="form-horizontal">
		<?php if(isset($_SESSION['err']) && $_SESSION['err'] == 1){ ?>
		<p class="text-danger">All fields have to be filled</p>
		<?php } ?>
		
		
        <div class="form-group">
            <label for="card_type" class="col-lg-2 control-label">Type</label>
            <div class="col-lg-10">
              	<select class="form-control" name="card_type" id="card_type">
                  	<option value="VISA">VISA</option>
                  	<option value="MasterCard">MasterCard</option>
                  	<option value="American Express">American Express</option>
              	</select>
            </div>
        </div>
        <div class="form-group">
            <label for="card_number" class="col-lg-2 control-label">Number</label>
            <div class="col-lg-10">
              	<input type="text" class="form-control" name="card_number"id="card_number">
            </div>
        </div>
        <div class="form-group">
            <label for="card_PID" class="col-lg-2 control-label">Card PIN</label>
            <div class="col-lg-10">
              	<input type="text" class="form-control" name="card_PID" id="card_PID">
            </div>
        </div>
        <div class="form-group">
            <label for="card_expire" class="col-lg-2 control-label">Expiry Date</label>
            <div class="col-lg-10">
              	<input type="date" name="card_expire" id="card_expire" class="form-control">
            </div>
        </div>
        <div class="form-group">
            <label for="card_owner" class="col-lg-2 control-label">Name</label>
            <div class="col-lg-10">
              	<input type="text" class="form-control" name="card_owner" id="card_owner">
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-10 col-lg-offset-2">
              	<button type="reset" class="btn btn-danger">Cancel</button>
              	<button type="submit" class="btn btn-danger">Purchase</button>
            </div>
        </div>
    </form>
    
     </div>
     
</div>

</div>
</div>
</div>
</div>
</div>


	<p class="lead">Please press Purchase to confirm your purchase, or Continue Shopping to add or remove items.
	<a href="dashboard.php" class="btn btn-info">Continue Shopping</a></p>
<?php
	} else {
		echo "<p class=\"text-warning\">Your cart is empty! Please make sure you add some books in it!</p>";
	}

?>


                </td>
                
        </tr>
    </table>
    
</div>