
<?php 

include('includes/config.php');

$distt=array();
$ii=0;

$st=$_POST["state_id"];

$sql="SELECT * FROM district WHERE StCode ='$st'";
$query=$dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0)
{
    foreach($results as $result)
    {   
        $did= $result->DistCode;
        $dname= $result->DistrictName;
        $distt[$ii]['id']=$did;
        $distt[$ii]['value']=$dname;
        $ii++;
    }
}
echo json_encode($distt);

?>