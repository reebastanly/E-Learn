<?php

include('includes/config.php');

    $sql = "SELECT image FROM storeimages WHERE id='3';";
    $query = $dbh->prepare($sql);
    $query-> execute();
    $num = $query->rowCount();
    
    if( $num )
    {
        $row = $query->fetch(PDO::FETCH_ASSOC);
        header("Content-type: image/jpg");
        print $row['image'];
    }
    else 
    {
    echo 'Please use a real id number';
    }

?>