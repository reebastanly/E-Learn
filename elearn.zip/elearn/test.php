<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form method="POST" name="frm1">
<table border="1">
<tr>
<td>name</td>
<td><input type="text" name="name" id="name"  value="<?php  echo $_POST['name'];?>"/></td>

</tr>
<tr>
<td>ID</td>
<td><input type="text" name="id" id="id" value="<?php  echo $_POST['id'];?>" /></td>
</tr>
<tr>
<td>gender</td>
<td><input type="radio" name="gender" id="gender" value="male"  <?php if (  $_POST ['gender']=='male' )
{ echo "checked";}
?> />male
<input type="radio" name="gender" id="gender" value="female" <?php if (  $_POST ['gender']=='female' )
{ echo "checked";} ?>/> female
</td>
</tr>
<tr>
<td><input type="submit" name="ok" id="ok" value="ok"></button></td>
<td></td>
</tr>


</table>
</form>
</body>
</html>

<?php
if(isset($_POST['ok']))
{
$db_host="localhost";
$db_pass="";
$db_name="elearn";
$db_user="root";
try
{
$dbh = new PDO("mysql:host=$db_host;dbname=$db_name",$db_user,$db_pass,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
  
$n=$_POST['name'];
$i=$_POST['id'];
//$sql="insert into test values ('$n',$i)";
$sql="update test  set name='$n' where id=$i";
//insert into test(id,'name') values (1,'akhil')(ehu clm ariyillatha sahacharyathil used-another way
$query = $dbh->prepare($sql);
$query->execute();
}			
?>